package psybnc.pack;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class psy extends android.app.Service {
	public static class psy_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
			android.content.Intent in = new android.content.Intent(context, psy.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
			context.startService(in);
		}

	}
    static psy mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return psy.class;
	}
	@Override
	public void onCreate() {
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "psybnc.pack", "psybnc.pack.psy");
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        processBA.setActivityPaused(false);
        anywheresoftware.b4a.keywords.Common.Log("** Service (psy) Create **");
        processBA.raiseEvent(null, "service_create");
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		handleStart(intent);
    }
    @Override
    public int onStartCommand(android.content.Intent intent, int flags, int startId) {
    	handleStart(intent);
		return android.app.Service.START_NOT_STICKY;
    }
    private void handleStart(android.content.Intent intent) {
    	anywheresoftware.b4a.keywords.Common.Log("** Service (psy) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = new anywheresoftware.b4a.objects.IntentWrapper();
    			if (intent != null) {
    				if (intent.hasExtra("b4a_internal_intent"))
    					iw.setObject((android.content.Intent) intent.getParcelableExtra("b4a_internal_intent"));
    				else
    					iw.setObject(intent);
    			}
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}
	@Override
	public void onDestroy() {
        anywheresoftware.b4a.keywords.Common.Log("** Service (psy) Destroy **");
		processBA.raiseEvent(null, "service_destroy");
        processBA.service = null;
		mostCurrent = null;
		processBA.setActivityPaused(true);
	}
public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static String _serverport = "";
public static boolean _statesocket = false;
public static anywheresoftware.b4a.objects.SocketWrapper _socket_ricezione_dati = null;
public static anywheresoftware.b4a.objects.SocketWrapper _socket_invio_dati = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _datisocket_ricezione = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _datisocket_ricezione_irc = null;
public static boolean _irclient = false;
public static String _myip = "";
public static anywheresoftware.b4a.objects.Timer _timerserver = null;
public static boolean _joinpasswd = false;
public static anywheresoftware.b4a.objects.collections.List _joinchannel = null;
public static anywheresoftware.b4a.objects.collections.List _topichannel = null;
public static anywheresoftware.b4a.objects.collections.List _messagequery = null;
public static String _identirc = "";
public static String _nickconnessione = "";
public static String _savemoth = "";
public static boolean _stopmoth = false;
public static String _awaynick = "";
public static String _normalnick = "";
public static anywheresoftware.b4a.objects.Timer _pingtimer = null;
public static boolean _autoping = false;
public psybnc.pack.main _main = null;
public static String  _bhelp() throws Exception{
		Debug.PushSubsStack("Bhelp (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
 BA.debugLineNum = 577;BA.debugLine="Sub Bhelp()";
Debug.ShouldStop(1);
 BA.debugLineNum = 578;BA.debugLine="Dim tr As TextReader";
Debug.ShouldStop(2);
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();Debug.locals.put("tr", _tr);
 BA.debugLineNum = 579;BA.debugLine="Dim tw As TextWriter";
Debug.ShouldStop(4);
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("tw", _tw);
 BA.debugLineNum = 580;BA.debugLine="tr.Initialize( socket_ricezione_dati.InputStream)";
Debug.ShouldStop(8);
_tr.Initialize(_socket_ricezione_dati.getInputStream());
 BA.debugLineNum = 581;BA.debugLine="tw.Initialize( socket_ricezione_dati.OutputStream)";
Debug.ShouldStop(16);
_tw.Initialize(_socket_ricezione_dati.getOutputStream());
 BA.debugLineNum = 582;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC Welcome \"&Solouser(identIRC)&\" !\")";
Debug.ShouldStop(32);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC Welcome "+_solouser(_identirc)+" !");
 BA.debugLineNum = 583;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC You are the first To connect To this new proxy server.\")";
Debug.ShouldStop(64);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC You are the first To connect To this new proxy server.");
 BA.debugLineNum = 584;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC You are the proxy-admin. Use ADDSERVER To add a server so the bouncer may connect.\")";
Debug.ShouldStop(128);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC You are the proxy-admin. Use ADDSERVER To add a server so the bouncer may connect.");
 BA.debugLineNum = 585;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC psyBNC0.1 Help (* = BounceAdmin only)\")";
Debug.ShouldStop(256);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC psyBNC0.1 Help (* = BounceAdmin only)");
 BA.debugLineNum = 586;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC -------------------------------------\")";
Debug.ShouldStop(512);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC -------------------------------------");
 BA.debugLineNum = 587;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP   ADDSERVER       - Adds an IRC-server To your Serverlist\")";
Debug.ShouldStop(1024);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP   ADDSERVER       - Adds an IRC-server To your Serverlist");
 BA.debugLineNum = 588;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP   DELSERVER       - Deletes an IRC-Server by number\")";
Debug.ShouldStop(2048);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP   DELSERVER       - Deletes an IRC-Server by number");
 BA.debugLineNum = 589;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP   LISTSERVERS     - Lists all IRC-Servers added\")";
Debug.ShouldStop(4096);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP   LISTSERVERS     - Lists all IRC-Servers added");
 BA.debugLineNum = 590;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP   SETAWAYNICK     - Sets your nick when you are offline\")";
Debug.ShouldStop(8192);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP   SETAWAYNICK     - Sets your nick when you are offline");
 BA.debugLineNum = 591;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP   PLAYPRIVATELOG  - Plays your Message Log\")";
Debug.ShouldStop(16384);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP   PLAYPRIVATELOG  - Plays your Message Log");
 BA.debugLineNum = 592;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP   ERASEPRIVATELOG - Erases your Message Log\")";
Debug.ShouldStop(32768);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP   ERASEPRIVATELOG - Erases your Message Log");
 BA.debugLineNum = 593;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP   BHELP           - Lists this help OR help on a topic\")";
Debug.ShouldStop(65536);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP   BHELP           - Lists this help OR help on a topic");
 BA.debugLineNum = 594;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP Use /QUOTE bhelp <command> For details.\")";
Debug.ShouldStop(131072);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP Use /QUOTE bhelp <command> For details.");
 BA.debugLineNum = 595;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC BHELP - End of help\")";
Debug.ShouldStop(262144);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC BHELP - End of help");
 BA.debugLineNum = 596;BA.debugLine="tw.Flush";
Debug.ShouldStop(524288);
_tw.Flush();
 BA.debugLineNum = 597;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _clientinvio(String _read) throws Exception{
		Debug.PushSubsStack("ClientInvio (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
String _fileconf = "";
boolean _beginlogin = false;
String _readpasswd = "";
String[] _spacenick = null;
String[] _solonick = null;
String[] _linefile = null;
String[] _onlypass = null;
String[] _soloserver = null;
String _soloporta = "";
String[] _spazioriga = null;
String[] _porta = null;
String[] _stringconnection = null;
String _realdata = "";
String _numero = "";
int _i = 0;
Debug.locals.put("Read", _read);
 BA.debugLineNum = 600;BA.debugLine="Sub ClientInvio(Read As String)";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 602;BA.debugLine="Dim tr As TextReader";
Debug.ShouldStop(33554432);
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();Debug.locals.put("tr", _tr);
 BA.debugLineNum = 603;BA.debugLine="Dim tw As TextWriter";
Debug.ShouldStop(67108864);
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("tw", _tw);
 BA.debugLineNum = 606;BA.debugLine="If Read.Contains(\"CAP LS\") = True Then";
Debug.ShouldStop(536870912);
if (_read.contains("CAP LS")==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 607;BA.debugLine="IRClient = True";
Debug.ShouldStop(1073741824);
_irclient = anywheresoftware.b4a.keywords.Common.True;
 };
 BA.debugLineNum = 613;BA.debugLine="If Read.Contains(\"NICK\") AND IRClient == True AND joinpasswd = False Then";
Debug.ShouldStop(16);
if (_read.contains("NICK") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.False) { 
 BA.debugLineNum = 614;BA.debugLine="tr.Initialize( socket_ricezione_dati.InputStream)";
Debug.ShouldStop(32);
_tr.Initialize(_socket_ricezione_dati.getInputStream());
 BA.debugLineNum = 615;BA.debugLine="tw.Initialize( socket_ricezione_dati.OutputStream)";
Debug.ShouldStop(64);
_tw.Initialize(_socket_ricezione_dati.getOutputStream());
 BA.debugLineNum = 616;BA.debugLine="tw.WriteLine(\": Welcome NOTICE :psyBNC 0.1\")";
Debug.ShouldStop(128);
_tw.WriteLine(": Welcome NOTICE :psyBNC 0.1");
 BA.debugLineNum = 617;BA.debugLine="tw.WriteLine(\": -psyBNC NOTICE :Your IRC Client did not support a password. Please type /QUOTE PASS yourpassword to connect.\")";
Debug.ShouldStop(256);
_tw.WriteLine(": -psyBNC NOTICE :Your IRC Client did not support a password. Please type /QUOTE PASS yourpassword to connect.");
 BA.debugLineNum = 618;BA.debugLine="identIRC = Read.Replace(\"CAP LS\",\"\")";
Debug.ShouldStop(512);
_identirc = _read.replace("CAP LS","");
 BA.debugLineNum = 619;BA.debugLine="tw.Flush";
Debug.ShouldStop(1024);
_tw.Flush();
 };
 BA.debugLineNum = 625;BA.debugLine="If Read.ToUpperCase.Contains(\"PASSWORD\") OR Read.ToUpperCase.Contains(\"PASS\") AND IRClient == True AND identIRC.Length > 0 Then";
Debug.ShouldStop(65536);
if (_read.toUpperCase().contains("PASSWORD") || _read.toUpperCase().contains("PASS") && _irclient==anywheresoftware.b4a.keywords.Common.True && _identirc.length()>0) { 
 BA.debugLineNum = 627;BA.debugLine="Dim fileconf As String";
Debug.ShouldStop(262144);
_fileconf = "";Debug.locals.put("fileconf", _fileconf);
 BA.debugLineNum = 628;BA.debugLine="Dim BeginLogin As Boolean";
Debug.ShouldStop(524288);
_beginlogin = false;Debug.locals.put("BeginLogin", _beginlogin);
 BA.debugLineNum = 630;BA.debugLine="Dim readpasswd As String";
Debug.ShouldStop(2097152);
_readpasswd = "";Debug.locals.put("readpasswd", _readpasswd);
 BA.debugLineNum = 631;BA.debugLine="readpasswd = TogliPrimoComando(Read)";
Debug.ShouldStop(4194304);
_readpasswd = _togliprimocomando(_read);Debug.locals.put("readpasswd", _readpasswd);
 BA.debugLineNum = 633;BA.debugLine="fileconf = ReadFile(\"psybnc.conf\")";
Debug.ShouldStop(16777216);
_fileconf = _readfile("psybnc.conf");Debug.locals.put("fileconf", _fileconf);
 BA.debugLineNum = 635;BA.debugLine="If (fileconf.Length == 0)Then";
Debug.ShouldStop(67108864);
if ((_fileconf.length()==0)) { 
 BA.debugLineNum = 638;BA.debugLine="WriteFile(\"psybnc.conf\", identIRC.Replace(Chr(13),\"\"))";
Debug.ShouldStop(536870912);
_writefile("psybnc.conf",_identirc.replace(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))),""));
 BA.debugLineNum = 639;BA.debugLine="WriteFile(\"psybnc.conf\", \"PASSWD \"&readpasswd)";
Debug.ShouldStop(1073741824);
_writefile("psybnc.conf","PASSWD "+_readpasswd);
 BA.debugLineNum = 640;BA.debugLine="Dim Spacenick() As String";
Debug.ShouldStop(-2147483648);
_spacenick = new String[(int)(0)];
java.util.Arrays.fill(_spacenick,"");Debug.locals.put("Spacenick", _spacenick);
 BA.debugLineNum = 641;BA.debugLine="Dim Solonick() As String";
Debug.ShouldStop(1);
_solonick = new String[(int)(0)];
java.util.Arrays.fill(_solonick,"");Debug.locals.put("Solonick", _solonick);
 BA.debugLineNum = 642;BA.debugLine="Spacenick = Regex.Split(Chr(32),identIRC)";
Debug.ShouldStop(2);
_spacenick = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32))),_identirc);Debug.locals.put("Spacenick", _spacenick);
 BA.debugLineNum = 643;BA.debugLine="Solonick = Regex.Split(Chr(10),Spacenick(1))";
Debug.ShouldStop(4);
_solonick = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(10))),_spacenick[(int)(1)]);Debug.locals.put("Solonick", _solonick);
 BA.debugLineNum = 644;BA.debugLine="Nickconnessione = Solonick(0)";
Debug.ShouldStop(8);
_nickconnessione = _solonick[(int)(0)];
 BA.debugLineNum = 646;BA.debugLine="Bhelp";
Debug.ShouldStop(32);
_bhelp();
 BA.debugLineNum = 647;BA.debugLine="joinpasswd = True";
Debug.ShouldStop(64);
_joinpasswd = anywheresoftware.b4a.keywords.Common.True;
 BA.debugLineNum = 648;BA.debugLine="Return \"\"";
Debug.ShouldStop(128);
if (true) return "";
 }else {
 BA.debugLineNum = 651;BA.debugLine="Dim Linefile() As String";
Debug.ShouldStop(1024);
_linefile = new String[(int)(0)];
java.util.Arrays.fill(_linefile,"");Debug.locals.put("Linefile", _linefile);
 BA.debugLineNum = 652;BA.debugLine="Dim onlypass() As String";
Debug.ShouldStop(2048);
_onlypass = new String[(int)(0)];
java.util.Arrays.fill(_onlypass,"");Debug.locals.put("onlypass", _onlypass);
 BA.debugLineNum = 653;BA.debugLine="Linefile = Regex.split(Chr(13),fileconf)";
Debug.ShouldStop(4096);
_linefile = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))),_fileconf);Debug.locals.put("Linefile", _linefile);
 BA.debugLineNum = 654;BA.debugLine="onlypass = Regex.split(Chr(32),Linefile(2))";
Debug.ShouldStop(8192);
_onlypass = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32))),_linefile[(int)(2)]);Debug.locals.put("onlypass", _onlypass);
 BA.debugLineNum = 656;BA.debugLine="If onlypass(1) == readpasswd.SubString2(0,readpasswd.Length -1) Then";
Debug.ShouldStop(32768);
if ((_onlypass[(int)(1)]).equals(_readpasswd.substring((int)(0),(int)(_readpasswd.length()-1)))) { 
 BA.debugLineNum = 657;BA.debugLine="joinpasswd = True";
Debug.ShouldStop(65536);
_joinpasswd = anywheresoftware.b4a.keywords.Common.True;
 BA.debugLineNum = 658;BA.debugLine="QueryMSG";
Debug.ShouldStop(131072);
_querymsg();
 BA.debugLineNum = 659;BA.debugLine="If Linefile.Length > 3 Then";
Debug.ShouldStop(262144);
if (_linefile.length>3) { 
 BA.debugLineNum = 661;BA.debugLine="If socket_invio_dati.Connected = False Then";
Debug.ShouldStop(1048576);
if (_socket_invio_dati.getConnected()==anywheresoftware.b4a.keywords.Common.False) { 
 BA.debugLineNum = 662;BA.debugLine="Bhelp";
Debug.ShouldStop(2097152);
_bhelp();
 }else {
 BA.debugLineNum = 664;BA.debugLine="RejoinChannel";
Debug.ShouldStop(8388608);
_rejoinchannel();
 };
 };
 BA.debugLineNum = 667;BA.debugLine="Return \"\"";
Debug.ShouldStop(67108864);
if (true) return "";
 };
 };
 };
 BA.debugLineNum = 674;BA.debugLine="If Read.ToUpperCase.Contains(\"ADDSERVER\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(2);
if (_read.toUpperCase().contains("ADDSERVER") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 675;BA.debugLine="Dim soloserver() As String";
Debug.ShouldStop(4);
_soloserver = new String[(int)(0)];
java.util.Arrays.fill(_soloserver,"");Debug.locals.put("soloserver", _soloserver);
 BA.debugLineNum = 676;BA.debugLine="Dim soloporta As String";
Debug.ShouldStop(8);
_soloporta = "";Debug.locals.put("soloporta", _soloporta);
 BA.debugLineNum = 677;BA.debugLine="Read = TogliPrimoComando(Read.ToUpperCase)";
Debug.ShouldStop(16);
_read = _togliprimocomando(_read.toUpperCase());Debug.locals.put("Read", _read);
 BA.debugLineNum = 678;BA.debugLine="soloserver  = Regex.split(\":\",Read.ToUpperCase)";
Debug.ShouldStop(32);
_soloserver = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_read.toUpperCase());Debug.locals.put("soloserver", _soloserver);
 BA.debugLineNum = 679;BA.debugLine="If soloserver.Length -1 > 0 Then";
Debug.ShouldStop(64);
if (_soloserver.length-1>0) { 
 BA.debugLineNum = 680;BA.debugLine="soloporta = soloserver(1)";
Debug.ShouldStop(128);
_soloporta = _soloserver[(int)(1)];Debug.locals.put("soloporta", _soloporta);
 BA.debugLineNum = 681;BA.debugLine="WriteFileRiga(\"psybnc.conf\",\"server \"&soloserver(0) & \":\"& soloporta,4)";
Debug.ShouldStop(256);
_writefileriga("psybnc.conf","server "+_soloserver[(int)(0)]+":"+_soloporta,(long)(4));
 BA.debugLineNum = 682;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC Server \"&soloserver(0)&\" port \"&soloporta&\" (password: None) added.\")";
Debug.ShouldStop(512);
_writesocket(":-psyBNC PRIVMSG psyBNC Server "+_soloserver[(int)(0)]+" port "+_soloporta+" (password: None) added.");
 }else {
 BA.debugLineNum = 685;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC No server given. Syntax Is ADDSERVER hostname ::port\")";
Debug.ShouldStop(4096);
_writesocket(":-psyBNC PRIVMSG psyBNC No server given. Syntax Is ADDSERVER hostname ::port");
 };
 BA.debugLineNum = 687;BA.debugLine="Return \"\"";
Debug.ShouldStop(16384);
if (true) return "";
 };
 BA.debugLineNum = 692;BA.debugLine="If Read.ToUpperCase.Contains(\"LISTSERVERS\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(524288);
if (_read.toUpperCase().contains("LISTSERVERS") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 693;BA.debugLine="Dim SpazioRiga() As String";
Debug.ShouldStop(1048576);
_spazioriga = new String[(int)(0)];
java.util.Arrays.fill(_spazioriga,"");Debug.locals.put("SpazioRiga", _spazioriga);
 BA.debugLineNum = 694;BA.debugLine="Dim porta()  As String";
Debug.ShouldStop(2097152);
_porta = new String[(int)(0)];
java.util.Arrays.fill(_porta,"");Debug.locals.put("porta", _porta);
 BA.debugLineNum = 695;BA.debugLine="SpazioRiga = Regex.Split(\" \",LeggiFileRiga(\"psybnc.conf\",3))";
Debug.ShouldStop(4194304);
_spazioriga = anywheresoftware.b4a.keywords.Common.Regex.Split(" ",_leggifileriga("psybnc.conf",(long)(3)));Debug.locals.put("SpazioRiga", _spazioriga);
 BA.debugLineNum = 696;BA.debugLine="If SpazioRiga.Length > 1 Then";
Debug.ShouldStop(8388608);
if (_spazioriga.length>1) { 
 BA.debugLineNum = 697;BA.debugLine="porta = Regex.Split(\":\",SpazioRiga(1))";
Debug.ShouldStop(16777216);
_porta = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_spazioriga[(int)(1)]);Debug.locals.put("porta", _porta);
 BA.debugLineNum = 698;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC Server #1:\"&SpazioRiga(1)&\" port \"&porta(1))";
Debug.ShouldStop(33554432);
_writesocket(":-psyBNC PRIVMSG psyBNC Server #1:"+_spazioriga[(int)(1)]+" port "+_porta[(int)(1)]);
 };
 BA.debugLineNum = 700;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC End of Servers.\")";
Debug.ShouldStop(134217728);
_writesocket(":-psyBNC PRIVMSG psyBNC End of Servers.");
 BA.debugLineNum = 701;BA.debugLine="Return \"\"";
Debug.ShouldStop(268435456);
if (true) return "";
 };
 BA.debugLineNum = 706;BA.debugLine="If Read.ToUpperCase.Contains(\"JUMP\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(2);
if (_read.toUpperCase().contains("JUMP") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 707;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC Jump New Server.\")";
Debug.ShouldStop(4);
_writesocket(":-psyBNC PRIVMSG psyBNC Jump New Server.");
 BA.debugLineNum = 708;BA.debugLine="socket_invio_dati.close";
Debug.ShouldStop(8);
_socket_invio_dati.Close();
 BA.debugLineNum = 709;BA.debugLine="Dim SpazioRiga() As String";
Debug.ShouldStop(16);
_spazioriga = new String[(int)(0)];
java.util.Arrays.fill(_spazioriga,"");Debug.locals.put("SpazioRiga", _spazioriga);
 BA.debugLineNum = 710;BA.debugLine="Dim StringConnection()  As String";
Debug.ShouldStop(32);
_stringconnection = new String[(int)(0)];
java.util.Arrays.fill(_stringconnection,"");Debug.locals.put("StringConnection", _stringconnection);
 BA.debugLineNum = 711;BA.debugLine="SpazioRiga = Regex.Split(\" \",LeggiFileRiga(\"psybnc.conf\",3))";
Debug.ShouldStop(64);
_spazioriga = anywheresoftware.b4a.keywords.Common.Regex.Split(" ",_leggifileriga("psybnc.conf",(long)(3)));Debug.locals.put("SpazioRiga", _spazioriga);
 BA.debugLineNum = 712;BA.debugLine="Dim RealData As String";
Debug.ShouldStop(128);
_realdata = "";Debug.locals.put("RealData", _realdata);
 BA.debugLineNum = 713;BA.debugLine="RealData = GeneraDAtaUnix";
Debug.ShouldStop(256);
_realdata = _generadataunix();Debug.locals.put("RealData", _realdata);
 BA.debugLineNum = 714;BA.debugLine="If SpazioRiga.Length > 1 Then";
Debug.ShouldStop(512);
if (_spazioriga.length>1) { 
 BA.debugLineNum = 715;BA.debugLine="StringConnection = Regex.Split(\":\",SpazioRiga(1))";
Debug.ShouldStop(1024);
_stringconnection = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_spazioriga[(int)(1)]);Debug.locals.put("StringConnection", _stringconnection);
 BA.debugLineNum = 716;BA.debugLine="If StringConnection.Length = 2 Then";
Debug.ShouldStop(2048);
if (_stringconnection.length==2) { 
 BA.debugLineNum = 717;BA.debugLine="Topichannel.Clear";
Debug.ShouldStop(4096);
_topichannel.Clear();
 BA.debugLineNum = 718;BA.debugLine="socket_invio_dati.Close";
Debug.ShouldStop(8192);
_socket_invio_dati.Close();
 BA.debugLineNum = 719;BA.debugLine="socket_invio_dati.Initialize(\"socket_invio_dati\")";
Debug.ShouldStop(16384);
_socket_invio_dati.Initialize("socket_invio_dati");
 BA.debugLineNum = 720;BA.debugLine="socket_invio_dati.Connect(StringConnection(0),StringConnection(1),1000)";
Debug.ShouldStop(32768);
_socket_invio_dati.Connect(processBA,_stringconnection[(int)(0)],(int)(Double.parseDouble(_stringconnection[(int)(1)])),(int)(1000));
 BA.debugLineNum = 721;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC \"&RealData&\" :User \"&Solouser(identIRC)&\" () trying \"&StringConnection(0)&\" port \"&StringConnection(1)&\" ().\")";
Debug.ShouldStop(65536);
_writesocket(":-psyBNC PRIVMSG psyBNC "+_realdata+" :User "+_solouser(_identirc)+" () trying "+_stringconnection[(int)(0)]+" port "+_stringconnection[(int)(1)]+" ().");
 };
 };
 };
 BA.debugLineNum = 726;BA.debugLine="If Read.ToUpperCase.Contains(\"BHELP\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(2097152);
if (_read.toUpperCase().contains("BHELP") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 727;BA.debugLine="Bhelp";
Debug.ShouldStop(4194304);
_bhelp();
 };
 BA.debugLineNum = 732;BA.debugLine="If Read.ToUpperCase.Contains(\"DELSERVER\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(134217728);
if (_read.toUpperCase().contains("DELSERVER") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 733;BA.debugLine="Dim numero As String";
Debug.ShouldStop(268435456);
_numero = "";Debug.locals.put("numero", _numero);
 BA.debugLineNum = 734;BA.debugLine="numero = TogliPrimoComando(Read).Replace(Chr(10),\"\")";
Debug.ShouldStop(536870912);
_numero = _togliprimocomando(_read).replace(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(10))),"");Debug.locals.put("numero", _numero);
 BA.debugLineNum = 735;BA.debugLine="If numero = \"1\" Then";
Debug.ShouldStop(1073741824);
if ((_numero).equals("1")) { 
 BA.debugLineNum = 736;BA.debugLine="WriteFileRiga(\"psybnc.conf\",\"server\",4)";
Debug.ShouldStop(-2147483648);
_writefileriga("psybnc.conf","server",(long)(4));
 BA.debugLineNum = 737;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC Server 1 deleted.\")";
Debug.ShouldStop(1);
_writesocket(":-psyBNC PRIVMSG psyBNC Server 1 deleted.");
 };
 BA.debugLineNum = 739;BA.debugLine="Return \"\"";
Debug.ShouldStop(4);
if (true) return "";
 };
 BA.debugLineNum = 744;BA.debugLine="If Read.ToUpperCase.Contains(\"PLAYPRIVATELOG\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(128);
if (_read.toUpperCase().contains("PLAYPRIVATELOG") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 745;BA.debugLine="If MessageQuery.IsInitialized = True Then";
Debug.ShouldStop(256);
if (_messagequery.IsInitialized()==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 746;BA.debugLine="If MessageQuery.size-1 >= 0 Then";
Debug.ShouldStop(512);
if (_messagequery.getSize()-1>=0) { 
 BA.debugLineNum = 747;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psybnc Starting playing Log\")";
Debug.ShouldStop(1024);
_writesocket(":-psyBNC PRIVMSG psybnc Starting playing Log");
 BA.debugLineNum = 748;BA.debugLine="For i = 0 To MessageQuery.size -1";
Debug.ShouldStop(2048);
{
final double step562 = 1;
final double limit562 = (int)(_messagequery.getSize()-1);
for (_i = (int)(0); (step562 > 0 && _i <= limit562) || (step562 < 0 && _i >= limit562); _i += step562) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 749;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC \"& MessageQuery.Get(i))";
Debug.ShouldStop(4096);
_writesocket(":-psyBNC PRIVMSG psyBNC "+String.valueOf(_messagequery.Get(_i)));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 751;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC Use ERASEPRIVATELOG to kill the log\")";
Debug.ShouldStop(16384);
_writesocket(":-psyBNC PRIVMSG psyBNC Use ERASEPRIVATELOG to kill the log");
 };
 };
 BA.debugLineNum = 754;BA.debugLine="Return \"\"";
Debug.ShouldStop(131072);
if (true) return "";
 };
 BA.debugLineNum = 759;BA.debugLine="If Read.ToUpperCase.Contains(\"ERASEPRIVATELOG\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(4194304);
if (_read.toUpperCase().contains("ERASEPRIVATELOG") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 760;BA.debugLine="If MessageQuery.IsInitialized = True Then";
Debug.ShouldStop(8388608);
if (_messagequery.IsInitialized()==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 761;BA.debugLine="MessageQuery.Clear";
Debug.ShouldStop(16777216);
_messagequery.Clear();
 BA.debugLineNum = 762;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC Log erased\")";
Debug.ShouldStop(33554432);
_writesocket(":-psyBNC PRIVMSG psyBNC Log erased");
 };
 BA.debugLineNum = 764;BA.debugLine="Return \"\"";
Debug.ShouldStop(134217728);
if (true) return "";
 };
 BA.debugLineNum = 769;BA.debugLine="If Read.ToUpperCase.Contains(\"SETAWAYNICK\") AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(1);
if (_read.toUpperCase().contains("SETAWAYNICK") && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 770;BA.debugLine="AwayNick = TogliPrimoComando(Read).Replace(Chr(10),\"\")";
Debug.ShouldStop(2);
_awaynick = _togliprimocomando(_read).replace(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(10))),"");
 BA.debugLineNum = 771;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC AWAY-Nick changed to '\"&AwayNick & \"'.\")";
Debug.ShouldStop(4);
_writesocket(":-psyBNC PRIVMSG psyBNC AWAY-Nick changed to '"+_awaynick+"'.");
 BA.debugLineNum = 772;BA.debugLine="Return \"\"";
Debug.ShouldStop(8);
if (true) return "";
 };
 BA.debugLineNum = 778;BA.debugLine="If Read.ToUpperCase.Contains(\"QUIT :\") == False AND IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(512);
if (_read.toUpperCase().contains("QUIT :")==anywheresoftware.b4a.keywords.Common.False && _irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 779;BA.debugLine="WriteSocketIrc(Read)";
Debug.ShouldStop(1024);
_writesocketirc(_read);
 }else {
 BA.debugLineNum = 782;BA.debugLine="If Read.ToUpperCase.Contains(\"QUIT :\") == True Then";
Debug.ShouldStop(8192);
if (_read.toUpperCase().contains("QUIT :")==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 784;BA.debugLine="NormalNick = Nickconnessione";
Debug.ShouldStop(32768);
_normalnick = _nickconnessione;
 BA.debugLineNum = 785;BA.debugLine="WriteSocketIrc(\"nick \"&AwayNick)";
Debug.ShouldStop(65536);
_writesocketirc("nick "+_awaynick);
 BA.debugLineNum = 786;BA.debugLine="IRClient = False";
Debug.ShouldStop(131072);
_irclient = anywheresoftware.b4a.keywords.Common.False;
 BA.debugLineNum = 787;BA.debugLine="joinpasswd = False";
Debug.ShouldStop(262144);
_joinpasswd = anywheresoftware.b4a.keywords.Common.False;
 };
 };
 BA.debugLineNum = 792;BA.debugLine="End Sub";
Debug.ShouldStop(8388608);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _datisocket_ricezione_irc_newdata(byte[] _buffer) throws Exception{
		Debug.PushSubsStack("datisocket_ricezione_irc_NewData (psy) ","psy",1,processBA,mostCurrent);
try {
Debug.locals.put("buffer", _buffer);
 BA.debugLineNum = 798;BA.debugLine="Sub datisocket_ricezione_irc_NewData (buffer() As Byte)";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 799;BA.debugLine="WriteSocket(Ricezione_Server((BytesToString(buffer, 0, buffer.Length, \"UTF8\"))))";
Debug.ShouldStop(1073741824);
_writesocket(_ricezione_server((anywheresoftware.b4a.keywords.Common.BytesToString(_buffer,(int)(0),_buffer.length,"UTF8"))));
 BA.debugLineNum = 800;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _datisocket_ricezione_newdata(byte[] _buffer) throws Exception{
		Debug.PushSubsStack("datisocket_ricezione_NewData (psy) ","psy",1,processBA,mostCurrent);
try {
Debug.locals.put("buffer", _buffer);
 BA.debugLineNum = 795;BA.debugLine="Sub datisocket_ricezione_NewData (buffer() As Byte)";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 796;BA.debugLine="ClientInvio(BytesToString(buffer, 0, buffer.Length, \"UTF8\"))";
Debug.ShouldStop(134217728);
_clientinvio(anywheresoftware.b4a.keywords.Common.BytesToString(_buffer,(int)(0),_buffer.length,"UTF8"));
 BA.debugLineNum = 797;BA.debugLine="End Sub";
Debug.ShouldStop(268435456);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _generadataunix() throws Exception{
		Debug.PushSubsStack("GeneraDAtaUnix (psy) ","psy",1,processBA,mostCurrent);
try {
long _now = 0L;
String _realdate = "";
String[] _weekdaysstr = null;
String[] _mouth = null;
 BA.debugLineNum = 216;BA.debugLine="Sub GeneraDAtaUnix()";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 217;BA.debugLine="Dim now As Long";
Debug.ShouldStop(16777216);
_now = 0L;Debug.locals.put("now", _now);
 BA.debugLineNum = 218;BA.debugLine="Dim RealDate As String";
Debug.ShouldStop(33554432);
_realdate = "";Debug.locals.put("RealDate", _realdate);
 BA.debugLineNum = 219;BA.debugLine="now = DateTime.now";
Debug.ShouldStop(67108864);
_now = anywheresoftware.b4a.keywords.Common.DateTime.getNow();Debug.locals.put("now", _now);
 BA.debugLineNum = 220;BA.debugLine="Dim WeekDaysStr() As String";
Debug.ShouldStop(134217728);
_weekdaysstr = new String[(int)(0)];
java.util.Arrays.fill(_weekdaysstr,"");Debug.locals.put("WeekDaysStr", _weekdaysstr);
 BA.debugLineNum = 221;BA.debugLine="Dim Mouth() As String";
Debug.ShouldStop(268435456);
_mouth = new String[(int)(0)];
java.util.Arrays.fill(_mouth,"");Debug.locals.put("Mouth", _mouth);
 BA.debugLineNum = 222;BA.debugLine="WeekDaysStr = Array As String (\"Sun\", \"Mon\", \"Tue\", \"Wed\", \"Thu\", \"Fri\", \"Sat\")";
Debug.ShouldStop(536870912);
_weekdaysstr = new String[]{"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};Debug.locals.put("WeekDaysStr", _weekdaysstr);
 BA.debugLineNum = 223;BA.debugLine="Mouth = Array As String (\"Jan\", \"Feb\",\"Mar\", \"Apr\", \"May\", \"Jun\", \"Jul\", \"Aug\",\"Sept\",\"Oct\",\"Nov\",\"Dec\")";
Debug.ShouldStop(1073741824);
_mouth = new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"};Debug.locals.put("Mouth", _mouth);
 BA.debugLineNum = 224;BA.debugLine="RealDate = WeekDaysStr(DateTime.GetDayOfWeek(now) - 1) & \" \" & Mouth(DateTime.GetMonth(now)-1) & \" \" & DateTime.GetDayOfMonth(now) &\" \" &DateTime.GetHour(now)&\":\"&DateTime.GetMinute(now)&\":\"&DateTime.GetSecond(now)";
Debug.ShouldStop(-2147483648);
_realdate = _weekdaysstr[(int)(anywheresoftware.b4a.keywords.Common.DateTime.GetDayOfWeek(_now)-1)]+" "+_mouth[(int)(anywheresoftware.b4a.keywords.Common.DateTime.GetMonth(_now)-1)]+" "+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.GetDayOfMonth(_now))+" "+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.GetHour(_now))+":"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.GetMinute(_now))+":"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.GetSecond(_now));Debug.locals.put("RealDate", _realdate);
 BA.debugLineNum = 225;BA.debugLine="Return RealDate";
Debug.ShouldStop(1);
if (true) return _realdate;
 BA.debugLineNum = 226;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _leggifileriga(String _nomefile,long _riga) throws Exception{
		Debug.PushSubsStack("LeggiFileRiga (psy) ","psy",1,processBA,mostCurrent);
try {
String[] _iline = null;
Debug.locals.put("NomeFile", _nomefile);
Debug.locals.put("Riga", _riga);
 BA.debugLineNum = 130;BA.debugLine="Sub LeggiFileRiga(NomeFile As String,Riga As Long)";
Debug.ShouldStop(2);
 BA.debugLineNum = 131;BA.debugLine="Dim iLine() As String";
Debug.ShouldStop(4);
_iline = new String[(int)(0)];
java.util.Arrays.fill(_iline,"");Debug.locals.put("iLine", _iline);
 BA.debugLineNum = 132;BA.debugLine="iLine = Regex.Split(Chr(13),ReadFile(NomeFile))";
Debug.ShouldStop(8);
_iline = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))),_readfile(_nomefile));Debug.locals.put("iLine", _iline);
 BA.debugLineNum = 134;BA.debugLine="If  iLine.Length > 0 Then";
Debug.ShouldStop(32);
if (_iline.length>0) { 
 BA.debugLineNum = 135;BA.debugLine="If  Riga < iLine.Length Then";
Debug.ShouldStop(64);
if (_riga<_iline.length) { 
 BA.debugLineNum = 136;BA.debugLine="Return iLine(Riga)";
Debug.ShouldStop(128);
if (true) return _iline[(int)(_riga)];
 }else {
 BA.debugLineNum = 138;BA.debugLine="Return \"\"";
Debug.ShouldStop(512);
if (true) return "";
 };
 }else {
 BA.debugLineNum = 141;BA.debugLine="Return \"\"";
Debug.ShouldStop(4096);
if (true) return "";
 };
 BA.debugLineNum = 143;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _pingtimer_tick() throws Exception{
		Debug.PushSubsStack("PingTimer_Tick (psy) ","psy",1,processBA,mostCurrent);
try {
 BA.debugLineNum = 228;BA.debugLine="Sub PingTimer_Tick";
Debug.ShouldStop(8);
 BA.debugLineNum = 229;BA.debugLine="If AutoPing = True Then";
Debug.ShouldStop(16);
if (_autoping==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 230;BA.debugLine="WriteSocketIrc(\"PING :TIMEOUTCHECK\"&Chr(10))";
Debug.ShouldStop(32);
_writesocketirc("PING :TIMEOUTCHECK"+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(10))));
 BA.debugLineNum = 231;BA.debugLine="AutoPing=False";
Debug.ShouldStop(64);
_autoping = anywheresoftware.b4a.keywords.Common.False;
 };
 BA.debugLineNum = 233;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Dim server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Dim serverPort As String";
_serverport = "";
 //BA.debugLineNum = 15;BA.debugLine="Dim statesocket As Boolean";
_statesocket = false;
 //BA.debugLineNum = 18;BA.debugLine="Dim socket_ricezione_dati As Socket";
_socket_ricezione_dati = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim socket_invio_dati As Socket";
_socket_invio_dati = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim datisocket_ricezione As AsyncStreams";
_datisocket_ricezione = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 22;BA.debugLine="Dim datisocket_ricezione_irc As AsyncStreams";
_datisocket_ricezione_irc = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 26;BA.debugLine="Dim IRClient As Boolean";
_irclient = false;
 //BA.debugLineNum = 30;BA.debugLine="Dim MyIP As String";
_myip = "";
 //BA.debugLineNum = 33;BA.debugLine="Dim Timerserver As Timer";
_timerserver = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 36;BA.debugLine="Dim joinpasswd As Boolean";
_joinpasswd = false;
 //BA.debugLineNum = 40;BA.debugLine="Dim joinchannel As List";
_joinchannel = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 44;BA.debugLine="Dim Topichannel As List";
_topichannel = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 48;BA.debugLine="Dim MessageQuery As List";
_messagequery = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 51;BA.debugLine="Dim identIRC As String";
_identirc = "";
 //BA.debugLineNum = 52;BA.debugLine="Dim Nickconnessione As String";
_nickconnessione = "";
 //BA.debugLineNum = 54;BA.debugLine="Dim SaveMoth As String";
_savemoth = "";
 //BA.debugLineNum = 55;BA.debugLine="Dim StopMoth As Boolean";
_stopmoth = false;
 //BA.debugLineNum = 57;BA.debugLine="Dim AwayNick As String";
_awaynick = "";
 //BA.debugLineNum = 58;BA.debugLine="Dim NormalNick As String";
_normalnick = "";
 //BA.debugLineNum = 60;BA.debugLine="Dim PingTimer As Timer";
_pingtimer = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 61;BA.debugLine="Dim AutoPing As Boolean";
_autoping = false;
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public static String  _querymsg() throws Exception{
		Debug.PushSubsStack("QueryMSG (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
 BA.debugLineNum = 461;BA.debugLine="Sub QueryMSG()";
Debug.ShouldStop(4096);
 BA.debugLineNum = 462;BA.debugLine="If MessageQuery.IsInitialized = True Then";
Debug.ShouldStop(8192);
if (_messagequery.IsInitialized()==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 463;BA.debugLine="Dim tr As TextReader";
Debug.ShouldStop(16384);
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();Debug.locals.put("tr", _tr);
 BA.debugLineNum = 464;BA.debugLine="Dim tw As TextWriter";
Debug.ShouldStop(32768);
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("tw", _tw);
 BA.debugLineNum = 465;BA.debugLine="tr.Initialize( socket_ricezione_dati.InputStream)";
Debug.ShouldStop(65536);
_tr.Initialize(_socket_ricezione_dati.getInputStream());
 BA.debugLineNum = 466;BA.debugLine="tw.Initialize( socket_ricezione_dati.OutputStream)";
Debug.ShouldStop(131072);
_tw.Initialize(_socket_ricezione_dati.getOutputStream());
 BA.debugLineNum = 467;BA.debugLine="If MessageQuery.Size = 0 Then";
Debug.ShouldStop(262144);
if (_messagequery.getSize()==0) { 
 BA.debugLineNum = 468;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC You have no new Messages.\")";
Debug.ShouldStop(524288);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC You have no new Messages.");
 }else {
 BA.debugLineNum = 470;BA.debugLine="tw.WriteLine(\":-psyBNC PRIVMSG psyBNC You have Messages. Type /QUOTE PLAYPRIVATELOG To read your messages.\")";
Debug.ShouldStop(2097152);
_tw.WriteLine(":-psyBNC PRIVMSG psyBNC You have Messages. Type /QUOTE PLAYPRIVATELOG To read your messages.");
 };
 BA.debugLineNum = 472;BA.debugLine="tw.Flush";
Debug.ShouldStop(8388608);
_tw.Flush();
 };
 BA.debugLineNum = 474;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _readfile(String _nomefile) throws Exception{
		Debug.PushSubsStack("ReadFile (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _reader = null;
String _bufferfile = "";
String _line = "";
Debug.locals.put("NomeFile", _nomefile);
 BA.debugLineNum = 104;BA.debugLine="Sub ReadFile(NomeFile As String)  As String";
Debug.ShouldStop(128);
 BA.debugLineNum = 105;BA.debugLine="Dim Reader As TextReader";
Debug.ShouldStop(256);
_reader = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();Debug.locals.put("Reader", _reader);
 BA.debugLineNum = 106;BA.debugLine="Dim BufferFile As String";
Debug.ShouldStop(512);
_bufferfile = "";Debug.locals.put("BufferFile", _bufferfile);
 BA.debugLineNum = 107;BA.debugLine="If  File.Exists(File.DirInternal, NomeFile) == True Then";
Debug.ShouldStop(1024);
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_nomefile)==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 108;BA.debugLine="Reader.Initialize(File.OpenInput(File.DirInternal, NomeFile))";
Debug.ShouldStop(2048);
_reader.Initialize((java.io.InputStream)(anywheresoftware.b4a.keywords.Common.File.OpenInput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_nomefile).getObject()));
 BA.debugLineNum = 109;BA.debugLine="Dim line As String";
Debug.ShouldStop(4096);
_line = "";Debug.locals.put("line", _line);
 BA.debugLineNum = 110;BA.debugLine="line = Reader.ReadLine";
Debug.ShouldStop(8192);
_line = _reader.ReadLine();Debug.locals.put("line", _line);
 BA.debugLineNum = 111;BA.debugLine="Do While line <> Null";
Debug.ShouldStop(16384);
while (_line!= null) {
 BA.debugLineNum = 113;BA.debugLine="If BufferFile.Length > 0 Then";
Debug.ShouldStop(65536);
if (_bufferfile.length()>0) { 
 BA.debugLineNum = 114;BA.debugLine="BufferFile = BufferFile & Chr(13) & line";
Debug.ShouldStop(131072);
_bufferfile = _bufferfile+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13)))+_line;Debug.locals.put("BufferFile", _bufferfile);
 }else {
 BA.debugLineNum = 116;BA.debugLine="BufferFile = line";
Debug.ShouldStop(524288);
_bufferfile = _line;Debug.locals.put("BufferFile", _bufferfile);
 };
 BA.debugLineNum = 118;BA.debugLine="line = Reader.ReadLine";
Debug.ShouldStop(2097152);
_line = _reader.ReadLine();Debug.locals.put("line", _line);
 }
;
 BA.debugLineNum = 120;BA.debugLine="Reader.Close";
Debug.ShouldStop(8388608);
_reader.Close();
 };
 BA.debugLineNum = 122;BA.debugLine="Return BufferFile";
Debug.ShouldStop(33554432);
if (true) return _bufferfile;
 BA.debugLineNum = 123;BA.debugLine="End Sub";
Debug.ShouldStop(67108864);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _rejoinchannel() throws Exception{
		Debug.PushSubsStack("RejoinChannel (psy) ","psy",1,processBA,mostCurrent);
try {
long _i = 0L;
 BA.debugLineNum = 545;BA.debugLine="Sub RejoinChannel() As String";
Debug.ShouldStop(1);
 BA.debugLineNum = 546;BA.debugLine="If SaveMoth.Length > 0 Then";
Debug.ShouldStop(2);
if (_savemoth.length()>0) { 
 BA.debugLineNum = 547;BA.debugLine="Dim I As Long";
Debug.ShouldStop(4);
_i = 0L;Debug.locals.put("I", _i);
 BA.debugLineNum = 548;BA.debugLine="WriteSocketIrc(\"nick \"&NormalNick)";
Debug.ShouldStop(8);
_writesocketirc("nick "+_normalnick);
 BA.debugLineNum = 549;BA.debugLine="WriteSocket(SaveMoth.Replace(\"$nick :\",Nickconnessione&\" :\").Replace(\"$nick!\",Nickconnessione&\"!\"))";
Debug.ShouldStop(16);
_writesocket(_savemoth.replace("$nick :",_nickconnessione+" :").replace("$nick!",_nickconnessione+"!"));
 BA.debugLineNum = 550;BA.debugLine="For I = 0 To joinchannel.Size - 1";
Debug.ShouldStop(32);
{
final double step411 = 1;
final double limit411 = (long)(_joinchannel.getSize()-1);
for (_i = (long)(0); (step411 > 0 && _i <= limit411) || (step411 < 0 && _i >= limit411); _i += step411) {
Debug.locals.put("I", _i);
 BA.debugLineNum = 552;BA.debugLine="WriteSocket(\":\"&Nickconnessione &\"!psybnc@localhost.psybnc-arkosoft.com JOIN :\"&joinchannel.Get(I)&Chr(13))";
Debug.ShouldStop(128);
_writesocket(":"+_nickconnessione+"!psybnc@localhost.psybnc-arkosoft.com JOIN :"+String.valueOf(_joinchannel.Get((int)(_i)))+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))));
 BA.debugLineNum = 553;BA.debugLine="Try";
Debug.ShouldStop(256);
try { BA.debugLineNum = 554;BA.debugLine="WriteSocket(\":server.psybnc.com 332 \"&Nickconnessione&\" \"&joinchannel.Get(I)&Chr(13) &\" :\"&Topichannel.Get(I)&Chr(13))";
Debug.ShouldStop(512);
_writesocket(":server.psybnc.com 332 "+_nickconnessione+" "+String.valueOf(_joinchannel.Get((int)(_i)))+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13)))+" :"+String.valueOf(_topichannel.Get((int)(_i)))+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))));
 } 
       catch (Exception e416) {
			processBA.setLastException(e416); };
 BA.debugLineNum = 557;BA.debugLine="WriteSocketIrc(\"join \"&joinchannel.Get(I))";
Debug.ShouldStop(4096);
_writesocketirc("join "+String.valueOf(_joinchannel.Get((int)(_i))));
 BA.debugLineNum = 558;BA.debugLine="WriteSocketIrc(\"names \"&joinchannel.Get(I))";
Debug.ShouldStop(8192);
_writesocketirc("names "+String.valueOf(_joinchannel.Get((int)(_i))));
 }
}Debug.locals.put("I", _i);
;
 };
 BA.debugLineNum = 562;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _ricezione_server(String _read) throws Exception{
		Debug.PushSubsStack("Ricezione_Server (psy) ","psy",1,processBA,mostCurrent);
try {
String[] _pingstring = null;
String[] _rigaread = null;
String[] _numeroraw = null;
long _start = 0L;
String _changemoth = "";
int _nmrandom = 0;
String _f = "";
String _tildechan = "";
String[] _solovhost = null;
String _realdate = "";
String _messagetext = "";
String[] _solomsg = null;
String[] _solonick = null;
String[] _senzaduepunti = null;
String[] _realchan = null;
int _i = 0;
String _nomecanale = "";
String[] _toglipunti = null;
String[] _nuovonick = null;
Debug.locals.put("Read", _read);
 BA.debugLineNum = 235;BA.debugLine="Sub Ricezione_Server(Read As String )";
Debug.ShouldStop(1024);
 BA.debugLineNum = 241;BA.debugLine="Dim PingString() As String";
Debug.ShouldStop(65536);
_pingstring = new String[(int)(0)];
java.util.Arrays.fill(_pingstring,"");Debug.locals.put("PingString", _pingstring);
 BA.debugLineNum = 242;BA.debugLine="PingString = Regex.Split(\":\",Read)";
Debug.ShouldStop(131072);
_pingstring = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_read);Debug.locals.put("PingString", _pingstring);
 BA.debugLineNum = 243;BA.debugLine="If PingString(0) = \"PING \" Then";
Debug.ShouldStop(262144);
if ((_pingstring[(int)(0)]).equals("PING ")) { 
 BA.debugLineNum = 244;BA.debugLine="WriteSocketIrc(\"PONG \"&PingString(1)&Chr(13))";
Debug.ShouldStop(524288);
_writesocketirc("PONG "+_pingstring[(int)(1)]+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))));
 BA.debugLineNum = 245;BA.debugLine="AutoPing = True";
Debug.ShouldStop(1048576);
_autoping = anywheresoftware.b4a.keywords.Common.True;
 BA.debugLineNum = 246;BA.debugLine="Return \"\"";
Debug.ShouldStop(2097152);
if (true) return "";
 };
 BA.debugLineNum = 254;BA.debugLine="Dim RigaRead() As String";
Debug.ShouldStop(536870912);
_rigaread = new String[(int)(0)];
java.util.Arrays.fill(_rigaread,"");Debug.locals.put("RigaRead", _rigaread);
 BA.debugLineNum = 255;BA.debugLine="Dim NumeroRaw() As String";
Debug.ShouldStop(1073741824);
_numeroraw = new String[(int)(0)];
java.util.Arrays.fill(_numeroraw,"");Debug.locals.put("NumeroRaw", _numeroraw);
 BA.debugLineNum = 256;BA.debugLine="Dim Start As Long";
Debug.ShouldStop(-2147483648);
_start = 0L;Debug.locals.put("Start", _start);
 BA.debugLineNum = 257;BA.debugLine="RigaRead = Regex.Split(Chr(13),Read)";
Debug.ShouldStop(1);
_rigaread = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))),_read);Debug.locals.put("RigaRead", _rigaread);
 BA.debugLineNum = 258;BA.debugLine="For Start = 0 To RigaRead.Length -1";
Debug.ShouldStop(2);
{
final double step178 = 1;
final double limit178 = (long)(_rigaread.length-1);
for (_start = (long)(0); (step178 > 0 && _start <= limit178) || (step178 < 0 && _start >= limit178); _start += step178) {
Debug.locals.put("Start", _start);
 BA.debugLineNum = 259;BA.debugLine="If RigaRead(Start).Contains(Chr(32)) == True Then";
Debug.ShouldStop(4);
if (_rigaread[(int)(_start)].contains(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32))))==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 260;BA.debugLine="NumeroRaw = Regex.Split(Chr(32),RigaRead(Start))";
Debug.ShouldStop(8);
_numeroraw = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32))),_rigaread[(int)(_start)]);Debug.locals.put("NumeroRaw", _numeroraw);
 BA.debugLineNum = 262;BA.debugLine="If NumeroRaw.Length = 1 Then Return \"\"";
Debug.ShouldStop(32);
if (_numeroraw.length==1) { 
if (true) return "";};
 BA.debugLineNum = 264;BA.debugLine="If NumeroRaw(1) = \"376\" Then";
Debug.ShouldStop(128);
if ((_numeroraw[(int)(1)]).equals("376")) { 
 BA.debugLineNum = 265;BA.debugLine="SaveMoth =  SaveMoth & RigaRead(Start) & Chr(32)";
Debug.ShouldStop(256);
_savemoth = _savemoth+_rigaread[(int)(_start)]+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32)));
 BA.debugLineNum = 266;BA.debugLine="StopMoth = False";
Debug.ShouldStop(512);
_stopmoth = anywheresoftware.b4a.keywords.Common.False;
 BA.debugLineNum = 267;BA.debugLine="RejoinChannel";
Debug.ShouldStop(1024);
_rejoinchannel();
 };
 BA.debugLineNum = 270;BA.debugLine="If StopMoth = True Then";
Debug.ShouldStop(8192);
if (_stopmoth==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 271;BA.debugLine="SaveMoth =  SaveMoth & RigaRead(Start) & Chr(32)";
Debug.ShouldStop(16384);
_savemoth = _savemoth+_rigaread[(int)(_start)]+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32)));
 };
 BA.debugLineNum = 278;BA.debugLine="If NumeroRaw(1) = \"001\" Then";
Debug.ShouldStop(2097152);
if ((_numeroraw[(int)(1)]).equals("001")) { 
 BA.debugLineNum = 279;BA.debugLine="StopMoth = True";
Debug.ShouldStop(4194304);
_stopmoth = anywheresoftware.b4a.keywords.Common.True;
 BA.debugLineNum = 280;BA.debugLine="Nickconnessione = NumeroRaw(2)";
Debug.ShouldStop(8388608);
_nickconnessione = _numeroraw[(int)(2)];
 BA.debugLineNum = 281;BA.debugLine="changemoth = RigaRead(Start).Replace(Nickconnessione&\" :\",\"$nick :\").Replace(Nickconnessione&\"!\",\"$nick!\")";
Debug.ShouldStop(16777216);
_changemoth = _rigaread[(int)(_start)].replace(_nickconnessione+" :","$nick :").replace(_nickconnessione+"!","$nick!");Debug.locals.put("changemoth", _changemoth);
 BA.debugLineNum = 282;BA.debugLine="SaveMoth =  changemoth & Chr(32)";
Debug.ShouldStop(33554432);
_savemoth = _changemoth+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32)));
 };
 BA.debugLineNum = 288;BA.debugLine="If NumeroRaw(1)=\"433\" AND Nickconnessione.Length > 0 AND joinpasswd=False Then";
Debug.ShouldStop(-2147483648);
if ((_numeroraw[(int)(1)]).equals("433") && _nickconnessione.length()>0 && _joinpasswd==anywheresoftware.b4a.keywords.Common.False) { 
 BA.debugLineNum = 289;BA.debugLine="Dim nmrandom As Int";
Debug.ShouldStop(1);
_nmrandom = 0;Debug.locals.put("nmrandom", _nmrandom);
 BA.debugLineNum = 290;BA.debugLine="Dim f As String";
Debug.ShouldStop(2);
_f = "";Debug.locals.put("f", _f);
 BA.debugLineNum = 291;BA.debugLine="nmrandom = Rnd(1,10)";
Debug.ShouldStop(4);
_nmrandom = anywheresoftware.b4a.keywords.Common.Rnd((int)(1),(int)(10));Debug.locals.put("nmrandom", _nmrandom);
 BA.debugLineNum = 292;BA.debugLine="f= nmrandom";
Debug.ShouldStop(8);
_f = BA.NumberToString(_nmrandom);Debug.locals.put("f", _f);
 BA.debugLineNum = 293;BA.debugLine="WriteSocketIrc(\"nick \"&Nickconnessione&f)";
Debug.ShouldStop(16);
_writesocketirc("nick "+_nickconnessione+_f);
 };
 BA.debugLineNum = 299;BA.debugLine="If NumeroRaw(1) = \"PRIVMSG\" AND joinpasswd = False Then";
Debug.ShouldStop(1024);
if ((_numeroraw[(int)(1)]).equals("PRIVMSG") && _joinpasswd==anywheresoftware.b4a.keywords.Common.False) { 
 BA.debugLineNum = 300;BA.debugLine="Dim TildeChan As String";
Debug.ShouldStop(2048);
_tildechan = "";Debug.locals.put("TildeChan", _tildechan);
 BA.debugLineNum = 301;BA.debugLine="TildeChan = NumeroRaw(2).SubString2(0,1)";
Debug.ShouldStop(4096);
_tildechan = _numeroraw[(int)(2)].substring((int)(0),(int)(1));Debug.locals.put("TildeChan", _tildechan);
 BA.debugLineNum = 302;BA.debugLine="If TildeChan <> \"#\" AND TildeChan <> \"&\" Then";
Debug.ShouldStop(8192);
if ((_tildechan).equals("#") == false && (_tildechan).equals("&") == false) { 
 BA.debugLineNum = 304;BA.debugLine="Dim SoloVhost() As String";
Debug.ShouldStop(32768);
_solovhost = new String[(int)(0)];
java.util.Arrays.fill(_solovhost,"");Debug.locals.put("SoloVhost", _solovhost);
 BA.debugLineNum = 306;BA.debugLine="Dim RealDate As String";
Debug.ShouldStop(131072);
_realdate = "";Debug.locals.put("RealDate", _realdate);
 BA.debugLineNum = 307;BA.debugLine="SoloVhost = Regex.Split(\":\",NumeroRaw(0))";
Debug.ShouldStop(262144);
_solovhost = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_numeroraw[(int)(0)]);Debug.locals.put("SoloVhost", _solovhost);
 BA.debugLineNum = 308;BA.debugLine="RealDate = GeneraDAtaUnix";
Debug.ShouldStop(524288);
_realdate = _generadataunix();Debug.locals.put("RealDate", _realdate);
 BA.debugLineNum = 309;BA.debugLine="Dim Start As Long";
Debug.ShouldStop(1048576);
_start = 0L;Debug.locals.put("Start", _start);
 BA.debugLineNum = 310;BA.debugLine="Dim MessageText As String";
Debug.ShouldStop(2097152);
_messagetext = "";Debug.locals.put("MessageText", _messagetext);
 BA.debugLineNum = 311;BA.debugLine="For Start = 3 To NumeroRaw.Length -1";
Debug.ShouldStop(4194304);
{
final double step213 = 1;
final double limit213 = (long)(_numeroraw.length-1);
for (_start = (long)(3); (step213 > 0 && _start <= limit213) || (step213 < 0 && _start >= limit213); _start += step213) {
Debug.locals.put("Start", _start);
 BA.debugLineNum = 312;BA.debugLine="If Start = 3 Then";
Debug.ShouldStop(8388608);
if (_start==3) { 
 BA.debugLineNum = 313;BA.debugLine="Dim SoloMSG() As String";
Debug.ShouldStop(16777216);
_solomsg = new String[(int)(0)];
java.util.Arrays.fill(_solomsg,"");Debug.locals.put("SoloMSG", _solomsg);
 BA.debugLineNum = 314;BA.debugLine="SoloMSG = Regex.Split(\":\",NumeroRaw(3))";
Debug.ShouldStop(33554432);
_solomsg = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_numeroraw[(int)(3)]);Debug.locals.put("SoloMSG", _solomsg);
 BA.debugLineNum = 315;BA.debugLine="MessageText = SoloMSG(1)";
Debug.ShouldStop(67108864);
_messagetext = _solomsg[(int)(1)];Debug.locals.put("MessageText", _messagetext);
 }else {
 BA.debugLineNum = 317;BA.debugLine="MessageText = MessageText & \" \" & NumeroRaw(Start)";
Debug.ShouldStop(268435456);
_messagetext = _messagetext+" "+_numeroraw[(int)(_start)];Debug.locals.put("MessageText", _messagetext);
 };
 }
}Debug.locals.put("Start", _start);
;
 BA.debugLineNum = 320;BA.debugLine="MessageQuery.AddAll(Array As String(RealDate&\" :(\"&SoloVhost(1)&\")\"& \" \" &MessageText))";
Debug.ShouldStop(-2147483648);
_messagequery.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_realdate+" :("+_solovhost[(int)(1)]+")"+" "+_messagetext}));
 };
 };
 BA.debugLineNum = 326;BA.debugLine="If NumeroRaw(1) = \"JOIN\" Then";
Debug.ShouldStop(32);
if ((_numeroraw[(int)(1)]).equals("JOIN")) { 
 BA.debugLineNum = 327;BA.debugLine="Dim SolOnick() As String";
Debug.ShouldStop(64);
_solonick = new String[(int)(0)];
java.util.Arrays.fill(_solonick,"");Debug.locals.put("SolOnick", _solonick);
 BA.debugLineNum = 328;BA.debugLine="Dim SenzaDuePunti() As  String";
Debug.ShouldStop(128);
_senzaduepunti = new String[(int)(0)];
java.util.Arrays.fill(_senzaduepunti,"");Debug.locals.put("SenzaDuePunti", _senzaduepunti);
 BA.debugLineNum = 329;BA.debugLine="SolOnick = Regex.Split(\"!\",NumeroRaw(0))";
Debug.ShouldStop(256);
_solonick = anywheresoftware.b4a.keywords.Common.Regex.Split("!",_numeroraw[(int)(0)]);Debug.locals.put("SolOnick", _solonick);
 BA.debugLineNum = 330;BA.debugLine="SenzaDuePunti = Regex.Split(\":\",SolOnick(0))";
Debug.ShouldStop(512);
_senzaduepunti = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_solonick[(int)(0)]);Debug.locals.put("SenzaDuePunti", _senzaduepunti);
 BA.debugLineNum = 331;BA.debugLine="If SenzaDuePunti(1) = Nickconnessione Then";
Debug.ShouldStop(1024);
if ((_senzaduepunti[(int)(1)]).equals(_nickconnessione)) { 
 BA.debugLineNum = 332;BA.debugLine="Dim RealChan() As String";
Debug.ShouldStop(2048);
_realchan = new String[(int)(0)];
java.util.Arrays.fill(_realchan,"");Debug.locals.put("RealChan", _realchan);
 BA.debugLineNum = 333;BA.debugLine="RealChan = Regex.Split(\":\",NumeroRaw(2))";
Debug.ShouldStop(4096);
_realchan = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_numeroraw[(int)(2)]);Debug.locals.put("RealChan", _realchan);
 BA.debugLineNum = 334;BA.debugLine="joinchannel.AddAll(Array As String(RealChan(1)))";
Debug.ShouldStop(8192);
_joinchannel.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_realchan[(int)(1)]}));
 BA.debugLineNum = 335;BA.debugLine="Topichannel.addAll(Array As String(\"\"))";
Debug.ShouldStop(16384);
_topichannel.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{""}));
 };
 };
 BA.debugLineNum = 339;BA.debugLine="If NumeroRaw(1) =\"332\" Then";
Debug.ShouldStop(262144);
if ((_numeroraw[(int)(1)]).equals("332")) { 
 BA.debugLineNum = 340;BA.debugLine="For i = 0 To joinchannel.Size - 1";
Debug.ShouldStop(524288);
{
final double step238 = 1;
final double limit238 = (int)(_joinchannel.getSize()-1);
for (_i = (int)(0); (step238 > 0 && _i <= limit238) || (step238 < 0 && _i >= limit238); _i += step238) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 341;BA.debugLine="If NumeroRaw(3) = joinchannel.Get(i) Then";
Debug.ShouldStop(1048576);
if ((_numeroraw[(int)(3)]).equals(String.valueOf(_joinchannel.Get(_i)))) { 
 BA.debugLineNum = 342;BA.debugLine="SaveTopic(i,NumeroRaw)";
Debug.ShouldStop(2097152);
_savetopic((long)(_i),_numeroraw);
 };
 }
}Debug.locals.put("i", _i);
;
 };
 BA.debugLineNum = 351;BA.debugLine="If NumeroRaw(1) = \"PART\" Then";
Debug.ShouldStop(1073741824);
if ((_numeroraw[(int)(1)]).equals("PART")) { 
 BA.debugLineNum = 352;BA.debugLine="Dim SolOnick() As String";
Debug.ShouldStop(-2147483648);
_solonick = new String[(int)(0)];
java.util.Arrays.fill(_solonick,"");Debug.locals.put("SolOnick", _solonick);
 BA.debugLineNum = 353;BA.debugLine="Dim SenzaDuePunti() As  String";
Debug.ShouldStop(1);
_senzaduepunti = new String[(int)(0)];
java.util.Arrays.fill(_senzaduepunti,"");Debug.locals.put("SenzaDuePunti", _senzaduepunti);
 BA.debugLineNum = 354;BA.debugLine="Dim nomecanale As String";
Debug.ShouldStop(2);
_nomecanale = "";Debug.locals.put("nomecanale", _nomecanale);
 BA.debugLineNum = 355;BA.debugLine="SolOnick = Regex.Split(\"!\",NumeroRaw(0))";
Debug.ShouldStop(4);
_solonick = anywheresoftware.b4a.keywords.Common.Regex.Split("!",_numeroraw[(int)(0)]);Debug.locals.put("SolOnick", _solonick);
 BA.debugLineNum = 356;BA.debugLine="SenzaDuePunti = Regex.Split(\":\",SolOnick(0))";
Debug.ShouldStop(8);
_senzaduepunti = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_solonick[(int)(0)]);Debug.locals.put("SenzaDuePunti", _senzaduepunti);
 BA.debugLineNum = 357;BA.debugLine="If SenzaDuePunti(1) = Nickconnessione Then";
Debug.ShouldStop(16);
if ((_senzaduepunti[(int)(1)]).equals(_nickconnessione)) { 
 BA.debugLineNum = 358;BA.debugLine="For i = 0 To joinchannel.Size - 1";
Debug.ShouldStop(32);
{
final double step251 = 1;
final double limit251 = (int)(_joinchannel.getSize()-1);
for (_i = (int)(0); (step251 > 0 && _i <= limit251) || (step251 < 0 && _i >= limit251); _i += step251) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 359;BA.debugLine="If i <= joinchannel.Size -1 Then";
Debug.ShouldStop(64);
if (_i<=_joinchannel.getSize()-1) { 
 BA.debugLineNum = 360;BA.debugLine="nomecanale = joinchannel.Get(i)";
Debug.ShouldStop(128);
_nomecanale = String.valueOf(_joinchannel.Get(_i));Debug.locals.put("nomecanale", _nomecanale);
 BA.debugLineNum = 361;BA.debugLine="If NumeroRaw(2) = nomecanale Then";
Debug.ShouldStop(256);
if ((_numeroraw[(int)(2)]).equals(_nomecanale)) { 
 BA.debugLineNum = 362;BA.debugLine="If joinchannel.get(i) <> Null Then joinchannel.RemoveAt(i)";
Debug.ShouldStop(512);
if (_joinchannel.Get(_i)!= null) { 
_joinchannel.RemoveAt(_i);};
 BA.debugLineNum = 363;BA.debugLine="If Topichannel.get(i) <> Null Then Topichannel.removeAt(i)";
Debug.ShouldStop(1024);
if (_topichannel.Get(_i)!= null) { 
_topichannel.RemoveAt(_i);};
 };
 };
 }
}Debug.locals.put("i", _i);
;
 };
 BA.debugLineNum = 368;BA.debugLine="Return Read";
Debug.ShouldStop(32768);
if (true) return _read;
 };
 BA.debugLineNum = 373;BA.debugLine="If NumeroRaw(1) = \"TOPIC\" Then";
Debug.ShouldStop(1048576);
if ((_numeroraw[(int)(1)]).equals("TOPIC")) { 
 BA.debugLineNum = 374;BA.debugLine="For i = 0 To joinchannel.Size - 1";
Debug.ShouldStop(2097152);
{
final double step264 = 1;
final double limit264 = (int)(_joinchannel.getSize()-1);
for (_i = (int)(0); (step264 > 0 && _i <= limit264) || (step264 < 0 && _i >= limit264); _i += step264) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 375;BA.debugLine="If NumeroRaw(2) = joinchannel.Get(i) Then";
Debug.ShouldStop(4194304);
if ((_numeroraw[(int)(2)]).equals(String.valueOf(_joinchannel.Get(_i)))) { 
 BA.debugLineNum = 376;BA.debugLine="SaveTopic(i,NumeroRaw)";
Debug.ShouldStop(8388608);
_savetopic((long)(_i),_numeroraw);
 };
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 379;BA.debugLine="Return Read";
Debug.ShouldStop(67108864);
if (true) return _read;
 };
 BA.debugLineNum = 384;BA.debugLine="If NumeroRaw(1) = \"NICK\" Then";
Debug.ShouldStop(-2147483648);
if ((_numeroraw[(int)(1)]).equals("NICK")) { 
 BA.debugLineNum = 385;BA.debugLine="Dim SolOnick() As String";
Debug.ShouldStop(1);
_solonick = new String[(int)(0)];
java.util.Arrays.fill(_solonick,"");Debug.locals.put("SolOnick", _solonick);
 BA.debugLineNum = 386;BA.debugLine="Dim TogliPunti() As String";
Debug.ShouldStop(2);
_toglipunti = new String[(int)(0)];
java.util.Arrays.fill(_toglipunti,"");Debug.locals.put("TogliPunti", _toglipunti);
 BA.debugLineNum = 387;BA.debugLine="SolOnick = Regex.Split(\"!\",NumeroRaw(0))";
Debug.ShouldStop(4);
_solonick = anywheresoftware.b4a.keywords.Common.Regex.Split("!",_numeroraw[(int)(0)]);Debug.locals.put("SolOnick", _solonick);
 BA.debugLineNum = 388;BA.debugLine="TogliPunti = Regex.Split(\":\",SolOnick(0))";
Debug.ShouldStop(8);
_toglipunti = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_solonick[(int)(0)]);Debug.locals.put("TogliPunti", _toglipunti);
 BA.debugLineNum = 389;BA.debugLine="If TogliPunti(1) = Nickconnessione Then";
Debug.ShouldStop(16);
if ((_toglipunti[(int)(1)]).equals(_nickconnessione)) { 
 BA.debugLineNum = 390;BA.debugLine="Dim NuovoNick() As String";
Debug.ShouldStop(32);
_nuovonick = new String[(int)(0)];
java.util.Arrays.fill(_nuovonick,"");Debug.locals.put("NuovoNick", _nuovonick);
 BA.debugLineNum = 391;BA.debugLine="NuovoNick = Regex.Split(\":\",NumeroRaw(2))";
Debug.ShouldStop(64);
_nuovonick = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_numeroraw[(int)(2)]);Debug.locals.put("NuovoNick", _nuovonick);
 BA.debugLineNum = 392;BA.debugLine="Nickconnessione =NuovoNick(1)";
Debug.ShouldStop(128);
_nickconnessione = _nuovonick[(int)(1)];
 };
 BA.debugLineNum = 394;BA.debugLine="Return Read";
Debug.ShouldStop(512);
if (true) return _read;
 };
 BA.debugLineNum = 399;BA.debugLine="If NumeroRaw(1) = \"KICK\" Then";
Debug.ShouldStop(16384);
if ((_numeroraw[(int)(1)]).equals("KICK")) { 
 BA.debugLineNum = 400;BA.debugLine="If NumeroRaw(3) = Nickconnessione Then";
Debug.ShouldStop(32768);
if ((_numeroraw[(int)(3)]).equals(_nickconnessione)) { 
 BA.debugLineNum = 401;BA.debugLine="For i = 0 To joinchannel.Size - 1";
Debug.ShouldStop(65536);
{
final double step285 = 1;
final double limit285 = (int)(_joinchannel.getSize()-1);
for (_i = (int)(0); (step285 > 0 && _i <= limit285) || (step285 < 0 && _i >= limit285); _i += step285) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 402;BA.debugLine="If NumeroRaw(2) = joinchannel.Get(i) Then";
Debug.ShouldStop(131072);
if ((_numeroraw[(int)(2)]).equals(String.valueOf(_joinchannel.Get(_i)))) { 
 BA.debugLineNum = 403;BA.debugLine="joinchannel.RemoveAt(i)";
Debug.ShouldStop(262144);
_joinchannel.RemoveAt(_i);
 BA.debugLineNum = 404;BA.debugLine="Topichannel.removeAt(i)";
Debug.ShouldStop(524288);
_topichannel.RemoveAt(_i);
 };
 }
}Debug.locals.put("i", _i);
;
 };
 BA.debugLineNum = 408;BA.debugLine="Return Read";
Debug.ShouldStop(8388608);
if (true) return _read;
 };
 };
 }
}Debug.locals.put("Start", _start);
;
 BA.debugLineNum = 416;BA.debugLine="Return Read";
Debug.ShouldStop(-2147483648);
if (true) return _read;
 BA.debugLineNum = 418;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _savetopic(long _i,String[] _numeroraw) throws Exception{
		Debug.PushSubsStack("SaveTopic (psy) ","psy",1,processBA,mostCurrent);
try {
long _p = 0L;
String _totaletopic = "";
String[] _senzapunti = null;
Debug.locals.put("i", _i);
Debug.locals.put("NumeroRaw", _numeroraw);
 BA.debugLineNum = 174;BA.debugLine="Sub SaveTopic(i As Long,NumeroRaw() As String)";
Debug.ShouldStop(8192);
 BA.debugLineNum = 179;BA.debugLine="If NumeroRaw(1) = \"TOPIC\" Then";
Debug.ShouldStop(262144);
if ((_numeroraw[(int)(1)]).equals("TOPIC")) { 
 BA.debugLineNum = 180;BA.debugLine="Dim p As Long";
Debug.ShouldStop(524288);
_p = 0L;Debug.locals.put("p", _p);
 BA.debugLineNum = 181;BA.debugLine="Dim TotaleTopic As String";
Debug.ShouldStop(1048576);
_totaletopic = "";Debug.locals.put("TotaleTopic", _totaletopic);
 BA.debugLineNum = 182;BA.debugLine="TotaleTopic = \"\"";
Debug.ShouldStop(2097152);
_totaletopic = "";Debug.locals.put("TotaleTopic", _totaletopic);
 BA.debugLineNum = 183;BA.debugLine="For p = 3 To NumeroRaw.Length -1";
Debug.ShouldStop(4194304);
{
final double step118 = 1;
final double limit118 = (long)(_numeroraw.length-1);
for (_p = (long)(3); (step118 > 0 && _p <= limit118) || (step118 < 0 && _p >= limit118); _p += step118) {
Debug.locals.put("p", _p);
 BA.debugLineNum = 184;BA.debugLine="If p = 3 Then";
Debug.ShouldStop(8388608);
if (_p==3) { 
 BA.debugLineNum = 185;BA.debugLine="Dim TotaleTopic As String";
Debug.ShouldStop(16777216);
_totaletopic = "";Debug.locals.put("TotaleTopic", _totaletopic);
 BA.debugLineNum = 186;BA.debugLine="Dim SenzaPunti() As String";
Debug.ShouldStop(33554432);
_senzapunti = new String[(int)(0)];
java.util.Arrays.fill(_senzapunti,"");Debug.locals.put("SenzaPunti", _senzapunti);
 BA.debugLineNum = 187;BA.debugLine="SenzaPunti =  Regex.Split(\":\",NumeroRaw(p))";
Debug.ShouldStop(67108864);
_senzapunti = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_numeroraw[(int)(_p)]);Debug.locals.put("SenzaPunti", _senzapunti);
 BA.debugLineNum = 188;BA.debugLine="TotaleTopic = SenzaPunti(1) & Chr(32)";
Debug.ShouldStop(134217728);
_totaletopic = _senzapunti[(int)(1)]+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32)));Debug.locals.put("TotaleTopic", _totaletopic);
 }else {
 BA.debugLineNum = 190;BA.debugLine="If p = NumeroRaw.Length -1 Then";
Debug.ShouldStop(536870912);
if (_p==_numeroraw.length-1) { 
 BA.debugLineNum = 191;BA.debugLine="TotaleTopic = TotaleTopic  & NumeroRaw(p)";
Debug.ShouldStop(1073741824);
_totaletopic = _totaletopic+_numeroraw[(int)(_p)];Debug.locals.put("TotaleTopic", _totaletopic);
 }else {
 BA.debugLineNum = 193;BA.debugLine="TotaleTopic = TotaleTopic  & NumeroRaw(p) & Chr(32)";
Debug.ShouldStop(1);
_totaletopic = _totaletopic+_numeroraw[(int)(_p)]+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32)));Debug.locals.put("TotaleTopic", _totaletopic);
 };
 };
 }
}Debug.locals.put("p", _p);
;
 }else {
 BA.debugLineNum = 198;BA.debugLine="Dim p As Long";
Debug.ShouldStop(32);
_p = 0L;Debug.locals.put("p", _p);
 BA.debugLineNum = 199;BA.debugLine="For p = 4 To NumeroRaw.Length -1";
Debug.ShouldStop(64);
{
final double step134 = 1;
final double limit134 = (long)(_numeroraw.length-1);
for (_p = (long)(4); (step134 > 0 && _p <= limit134) || (step134 < 0 && _p >= limit134); _p += step134) {
Debug.locals.put("p", _p);
 BA.debugLineNum = 200;BA.debugLine="If p = 4 Then";
Debug.ShouldStop(128);
if (_p==4) { 
 BA.debugLineNum = 201;BA.debugLine="Dim TotaleTopic As String";
Debug.ShouldStop(256);
_totaletopic = "";Debug.locals.put("TotaleTopic", _totaletopic);
 BA.debugLineNum = 202;BA.debugLine="Dim SenzaPunti() As String";
Debug.ShouldStop(512);
_senzapunti = new String[(int)(0)];
java.util.Arrays.fill(_senzapunti,"");Debug.locals.put("SenzaPunti", _senzapunti);
 BA.debugLineNum = 203;BA.debugLine="SenzaPunti =  Regex.Split(\":\",NumeroRaw(p))";
Debug.ShouldStop(1024);
_senzapunti = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_numeroraw[(int)(_p)]);Debug.locals.put("SenzaPunti", _senzapunti);
 BA.debugLineNum = 204;BA.debugLine="TotaleTopic = SenzaPunti(1)";
Debug.ShouldStop(2048);
_totaletopic = _senzapunti[(int)(1)];Debug.locals.put("TotaleTopic", _totaletopic);
 }else {
 BA.debugLineNum = 206;BA.debugLine="TotaleTopic = TotaleTopic  & \" \"& NumeroRaw(p)";
Debug.ShouldStop(8192);
_totaletopic = _totaletopic+" "+_numeroraw[(int)(_p)];Debug.locals.put("TotaleTopic", _totaletopic);
 };
 }
}Debug.locals.put("p", _p);
;
 };
 BA.debugLineNum = 210;BA.debugLine="If i < Topichannel.Size Then";
Debug.ShouldStop(131072);
if (_i<_topichannel.getSize()) { 
 BA.debugLineNum = 211;BA.debugLine="Topichannel.Set(i, TotaleTopic)";
Debug.ShouldStop(262144);
_topichannel.Set((int)(_i),(Object)(_totaletopic));
 };
 BA.debugLineNum = 214;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
		Debug.PushSubsStack("Server_NewConnection (psy) ","psy",1,processBA,mostCurrent);
try {
Debug.locals.put("Successful", _successful);
Debug.locals.put("NewSocket", _newsocket);
 BA.debugLineNum = 92;BA.debugLine="Sub Server_NewConnection (Successful As Boolean, NewSocket As Socket)";
Debug.ShouldStop(134217728);
 BA.debugLineNum = 93;BA.debugLine="If Successful = True AND datisocket_ricezione.IsInitialized = False Then";
Debug.ShouldStop(268435456);
if (_successful==anywheresoftware.b4a.keywords.Common.True && _datisocket_ricezione.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 BA.debugLineNum = 94;BA.debugLine="socket_ricezione_dati = NewSocket";
Debug.ShouldStop(536870912);
_socket_ricezione_dati = _newsocket;
 BA.debugLineNum = 95;BA.debugLine="datisocket_ricezione.Initialize(socket_ricezione_dati.InputStream,  socket_ricezione_dati.OutputStream, \"datisocket_ricezione\")";
Debug.ShouldStop(1073741824);
_datisocket_ricezione.Initialize(processBA,_socket_ricezione_dati.getInputStream(),_socket_ricezione_dati.getOutputStream(),"datisocket_ricezione");
 BA.debugLineNum = 96;BA.debugLine="server.Listen";
Debug.ShouldStop(-2147483648);
_server.Listen();
 };
 BA.debugLineNum = 98;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _service_create() throws Exception{
		Debug.PushSubsStack("Service_Create (psy) ","psy",1,processBA,mostCurrent);
try {
 BA.debugLineNum = 65;BA.debugLine="Sub Service_Create";
Debug.ShouldStop(1);
 BA.debugLineNum = 69;BA.debugLine="End Sub";
Debug.ShouldStop(16);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _service_destroy() throws Exception{
		Debug.PushSubsStack("Service_Destroy (psy) ","psy",1,processBA,mostCurrent);
try {
 BA.debugLineNum = 100;BA.debugLine="Sub Service_Destroy";
Debug.ShouldStop(8);
 BA.debugLineNum = 102;BA.debugLine="End Sub";
Debug.ShouldStop(32);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
		Debug.PushSubsStack("Service_Start (psy) ","psy",1,processBA,mostCurrent);
try {
Debug.locals.put("StartingIntent", _startingintent);
 BA.debugLineNum = 73;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
Debug.ShouldStop(256);
 BA.debugLineNum = 74;BA.debugLine="joinpasswd = False";
Debug.ShouldStop(512);
_joinpasswd = anywheresoftware.b4a.keywords.Common.False;
 BA.debugLineNum = 75;BA.debugLine="server.Initialize(serverPort, \"Server\")";
Debug.ShouldStop(1024);
_server.Initialize(processBA,(int)(Double.parseDouble(_serverport)),"Server");
 BA.debugLineNum = 76;BA.debugLine="MyIP = server.GetMyIP";
Debug.ShouldStop(2048);
_myip = _server.GetMyIP();
 BA.debugLineNum = 77;BA.debugLine="server.listen";
Debug.ShouldStop(4096);
_server.Listen();
 BA.debugLineNum = 78;BA.debugLine="statesocket = True";
Debug.ShouldStop(8192);
_statesocket = anywheresoftware.b4a.keywords.Common.True;
 BA.debugLineNum = 80;BA.debugLine="Timerserver.Initialize(\"TimerServer\",100000)";
Debug.ShouldStop(32768);
_timerserver.Initialize(processBA,"TimerServer",(long)(100000));
 BA.debugLineNum = 81;BA.debugLine="Timerserver.Enabled = True";
Debug.ShouldStop(65536);
_timerserver.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 BA.debugLineNum = 83;BA.debugLine="PingTimer.Initialize(\"pingTimer\",10000)";
Debug.ShouldStop(262144);
_pingtimer.Initialize(processBA,"pingTimer",(long)(10000));
 BA.debugLineNum = 84;BA.debugLine="PingTimer.Enabled = True";
Debug.ShouldStop(524288);
_pingtimer.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 BA.debugLineNum = 86;BA.debugLine="joinchannel.initialize";
Debug.ShouldStop(2097152);
_joinchannel.Initialize();
 BA.debugLineNum = 87;BA.debugLine="Topichannel.initialize";
Debug.ShouldStop(4194304);
_topichannel.Initialize();
 BA.debugLineNum = 88;BA.debugLine="MessageQuery.Initialize";
Debug.ShouldStop(8388608);
_messagequery.Initialize();
 BA.debugLineNum = 90;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _socket_invio_dati_close() throws Exception{
		Debug.PushSubsStack("socket_invio_dati_close (psy) ","psy",1,processBA,mostCurrent);
try {
 BA.debugLineNum = 490;BA.debugLine="Sub socket_invio_dati_close()";
Debug.ShouldStop(512);
 BA.debugLineNum = 493;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _socket_invio_dati_connected(boolean _successful) throws Exception{
		Debug.PushSubsStack("socket_invio_dati_Connected (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
Debug.locals.put("Successful", _successful);
 BA.debugLineNum = 477;BA.debugLine="Sub socket_invio_dati_Connected (Successful As Boolean)";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 478;BA.debugLine="If Successful = True Then";
Debug.ShouldStop(536870912);
if (_successful==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 479;BA.debugLine="Dim tr As TextReader";
Debug.ShouldStop(1073741824);
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();Debug.locals.put("tr", _tr);
 BA.debugLineNum = 480;BA.debugLine="Dim tw As TextWriter";
Debug.ShouldStop(-2147483648);
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("tw", _tw);
 BA.debugLineNum = 481;BA.debugLine="tr.Initialize(socket_invio_dati.InputStream)";
Debug.ShouldStop(1);
_tr.Initialize(_socket_invio_dati.getInputStream());
 BA.debugLineNum = 482;BA.debugLine="tw.Initialize(socket_invio_dati.OutputStream)";
Debug.ShouldStop(2);
_tw.Initialize(_socket_invio_dati.getOutputStream());
 BA.debugLineNum = 483;BA.debugLine="tw.WriteLine(\"CAP LS\")";
Debug.ShouldStop(4);
_tw.WriteLine("CAP LS");
 BA.debugLineNum = 484;BA.debugLine="tw.Flush";
Debug.ShouldStop(8);
_tw.Flush();
 BA.debugLineNum = 485;BA.debugLine="tw.WriteLine(identIRC)";
Debug.ShouldStop(16);
_tw.WriteLine(_identirc);
 BA.debugLineNum = 486;BA.debugLine="tw.Flush";
Debug.ShouldStop(32);
_tw.Flush();
 BA.debugLineNum = 487;BA.debugLine="datisocket_ricezione_irc.Initialize(socket_invio_dati.InputStream, socket_invio_dati.OutputStream, \"datisocket_ricezione_irc\")";
Debug.ShouldStop(64);
_datisocket_ricezione_irc.Initialize(processBA,_socket_invio_dati.getInputStream(),_socket_invio_dati.getOutputStream(),"datisocket_ricezione_irc");
 };
 BA.debugLineNum = 489;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _solouser(String _identread) throws Exception{
		Debug.PushSubsStack("Solouser (psy) ","psy",1,processBA,mostCurrent);
try {
String[] _user = null;
String[] _space = null;
Debug.locals.put("IdentRead", _identread);
 BA.debugLineNum = 565;BA.debugLine="Sub Solouser(IdentRead As String)";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 566;BA.debugLine="If IdentRead.Length > 0 Then";
Debug.ShouldStop(2097152);
if (_identread.length()>0) { 
 BA.debugLineNum = 567;BA.debugLine="Dim User() As String";
Debug.ShouldStop(4194304);
_user = new String[(int)(0)];
java.util.Arrays.fill(_user,"");Debug.locals.put("User", _user);
 BA.debugLineNum = 568;BA.debugLine="Dim Space() As String";
Debug.ShouldStop(8388608);
_space = new String[(int)(0)];
java.util.Arrays.fill(_space,"");Debug.locals.put("Space", _space);
 BA.debugLineNum = 569;BA.debugLine="User = Regex.Split(\"USER\",IdentRead)";
Debug.ShouldStop(16777216);
_user = anywheresoftware.b4a.keywords.Common.Regex.Split("USER",_identread);Debug.locals.put("User", _user);
 BA.debugLineNum = 570;BA.debugLine="Space = Regex.Split(\" \",User(1))";
Debug.ShouldStop(33554432);
_space = anywheresoftware.b4a.keywords.Common.Regex.Split(" ",_user[(int)(1)]);Debug.locals.put("Space", _space);
 BA.debugLineNum = 571;BA.debugLine="Return Space(1)";
Debug.ShouldStop(67108864);
if (true) return _space[(int)(1)];
 };
 BA.debugLineNum = 574;BA.debugLine="End Sub";
Debug.ShouldStop(536870912);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _timerserver_tick() throws Exception{
		Debug.PushSubsStack("TimerServer_Tick (psy) ","psy",1,processBA,mostCurrent);
try {
boolean _valuesocket = false;
String[] _spazioriga = null;
String[] _stringconnection = null;
String _realdata = "";
 BA.debugLineNum = 495;BA.debugLine="Sub TimerServer_Tick";
Debug.ShouldStop(16384);
 BA.debugLineNum = 498;BA.debugLine="If server.IsInitialized = False Then";
Debug.ShouldStop(131072);
if (_server.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 BA.debugLineNum = 499;BA.debugLine="server.Initialize(serverPort, \"Server\")";
Debug.ShouldStop(262144);
_server.Initialize(processBA,(int)(Double.parseDouble(_serverport)),"Server");
 BA.debugLineNum = 500;BA.debugLine="MyIP = server.GetMyIP";
Debug.ShouldStop(524288);
_myip = _server.GetMyIP();
 BA.debugLineNum = 501;BA.debugLine="server.listen";
Debug.ShouldStop(1048576);
_server.Listen();
 };
 BA.debugLineNum = 506;BA.debugLine="Dim ValueSocket As Boolean";
Debug.ShouldStop(33554432);
_valuesocket = false;Debug.locals.put("ValueSocket", _valuesocket);
 BA.debugLineNum = 507;BA.debugLine="ValueSocket = socket_invio_dati.Connected";
Debug.ShouldStop(67108864);
_valuesocket = _socket_invio_dati.getConnected();Debug.locals.put("ValueSocket", _valuesocket);
 BA.debugLineNum = 508;BA.debugLine="If ValueSocket = False Then";
Debug.ShouldStop(134217728);
if (_valuesocket==anywheresoftware.b4a.keywords.Common.False) { 
 BA.debugLineNum = 509;BA.debugLine="Dim SpazioRiga() As String";
Debug.ShouldStop(268435456);
_spazioriga = new String[(int)(0)];
java.util.Arrays.fill(_spazioriga,"");Debug.locals.put("SpazioRiga", _spazioriga);
 BA.debugLineNum = 510;BA.debugLine="Dim StringConnection()  As String";
Debug.ShouldStop(536870912);
_stringconnection = new String[(int)(0)];
java.util.Arrays.fill(_stringconnection,"");Debug.locals.put("StringConnection", _stringconnection);
 BA.debugLineNum = 511;BA.debugLine="SpazioRiga = Regex.Split(\" \",LeggiFileRiga(\"psybnc.conf\",3))";
Debug.ShouldStop(1073741824);
_spazioriga = anywheresoftware.b4a.keywords.Common.Regex.Split(" ",_leggifileriga("psybnc.conf",(long)(3)));Debug.locals.put("SpazioRiga", _spazioriga);
 BA.debugLineNum = 512;BA.debugLine="Dim RealData As String";
Debug.ShouldStop(-2147483648);
_realdata = "";Debug.locals.put("RealData", _realdata);
 BA.debugLineNum = 513;BA.debugLine="RealData = GeneraDAtaUnix";
Debug.ShouldStop(1);
_realdata = _generadataunix();Debug.locals.put("RealData", _realdata);
 BA.debugLineNum = 514;BA.debugLine="If SpazioRiga.Length > 1 Then";
Debug.ShouldStop(2);
if (_spazioriga.length>1) { 
 BA.debugLineNum = 515;BA.debugLine="StringConnection = Regex.Split(\":\",SpazioRiga(1))";
Debug.ShouldStop(4);
_stringconnection = anywheresoftware.b4a.keywords.Common.Regex.Split(":",_spazioriga[(int)(1)]);Debug.locals.put("StringConnection", _stringconnection);
 BA.debugLineNum = 516;BA.debugLine="If StringConnection.Length = 2 Then";
Debug.ShouldStop(8);
if (_stringconnection.length==2) { 
 BA.debugLineNum = 517;BA.debugLine="Topichannel.Clear";
Debug.ShouldStop(16);
_topichannel.Clear();
 BA.debugLineNum = 518;BA.debugLine="socket_invio_dati.Close";
Debug.ShouldStop(32);
_socket_invio_dati.Close();
 BA.debugLineNum = 519;BA.debugLine="socket_invio_dati.Initialize(\"socket_invio_dati\")";
Debug.ShouldStop(64);
_socket_invio_dati.Initialize("socket_invio_dati");
 BA.debugLineNum = 520;BA.debugLine="socket_invio_dati.Connect(StringConnection(0),StringConnection(1),1000)";
Debug.ShouldStop(128);
_socket_invio_dati.Connect(processBA,_stringconnection[(int)(0)],(int)(Double.parseDouble(_stringconnection[(int)(1)])),(int)(1000));
 BA.debugLineNum = 521;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC \"&RealData&\" :User \"&Solouser(identIRC)&\" () trying \"&StringConnection(0)&\" port \"&StringConnection(1)&\" ().\")";
Debug.ShouldStop(256);
_writesocket(":-psyBNC PRIVMSG psyBNC "+_realdata+" :User "+_solouser(_identirc)+" () trying "+_stringconnection[(int)(0)]+" port "+_stringconnection[(int)(1)]+" ().");
 };
 }else {
 BA.debugLineNum = 524;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC \"&RealData&\" :User \"&Solouser(identIRC)&\" has no server added\")";
Debug.ShouldStop(2048);
_writesocket(":-psyBNC PRIVMSG psyBNC "+_realdata+" :User "+_solouser(_identirc)+" has no server added");
 };
 };
 BA.debugLineNum = 529;BA.debugLine="End Sub";
Debug.ShouldStop(65536);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _togliprimocomando(String _read) throws Exception{
		Debug.PushSubsStack("TogliPrimoComando (psy) ","psy",1,processBA,mostCurrent);
try {
String[] _spazio = null;
String _nuovocomando = "";
int _start = 0;
Debug.locals.put("Read", _read);
 BA.debugLineNum = 532;BA.debugLine="Sub TogliPrimoComando(Read As String) As String";
Debug.ShouldStop(524288);
 BA.debugLineNum = 533;BA.debugLine="Dim spazio() As String";
Debug.ShouldStop(1048576);
_spazio = new String[(int)(0)];
java.util.Arrays.fill(_spazio,"");Debug.locals.put("spazio", _spazio);
 BA.debugLineNum = 534;BA.debugLine="Dim nuovocomando As String";
Debug.ShouldStop(2097152);
_nuovocomando = "";Debug.locals.put("nuovocomando", _nuovocomando);
 BA.debugLineNum = 535;BA.debugLine="spazio = Regex.Split(Chr(32),Read)";
Debug.ShouldStop(4194304);
_spazio = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(32))),_read);Debug.locals.put("spazio", _spazio);
 BA.debugLineNum = 536;BA.debugLine="For start = 1 To spazio.Length -1";
Debug.ShouldStop(8388608);
{
final double step397 = 1;
final double limit397 = (int)(_spazio.length-1);
for (_start = (int)(1); (step397 > 0 && _start <= limit397) || (step397 < 0 && _start >= limit397); _start += step397) {
Debug.locals.put("start", _start);
 BA.debugLineNum = 537;BA.debugLine="If start == 1 Then";
Debug.ShouldStop(16777216);
if (_start==1) { 
 BA.debugLineNum = 538;BA.debugLine="nuovocomando = spazio(start)";
Debug.ShouldStop(33554432);
_nuovocomando = _spazio[_start];Debug.locals.put("nuovocomando", _nuovocomando);
 }else {
 BA.debugLineNum = 540;BA.debugLine="nuovocomando = nuovocomando & \" \" & spazio(start)";
Debug.ShouldStop(134217728);
_nuovocomando = _nuovocomando+" "+_spazio[_start];Debug.locals.put("nuovocomando", _nuovocomando);
 };
 }
}Debug.locals.put("start", _start);
;
 BA.debugLineNum = 543;BA.debugLine="Return nuovocomando";
Debug.ShouldStop(1073741824);
if (true) return _nuovocomando;
 BA.debugLineNum = 544;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _writefile(String _nomefile,String _write) throws Exception{
		Debug.PushSubsStack("WriteFile (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _writer = null;
Debug.locals.put("NOmeFile", _nomefile);
Debug.locals.put("Write", _write);
 BA.debugLineNum = 124;BA.debugLine="Sub WriteFile(NOmeFile As String,Write As String )";
Debug.ShouldStop(134217728);
 BA.debugLineNum = 125;BA.debugLine="Dim Writer As TextWriter";
Debug.ShouldStop(268435456);
_writer = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("Writer", _writer);
 BA.debugLineNum = 126;BA.debugLine="Writer.Initialize(File.OpenOutput(File.DirInternal, NOmeFile, True))";
Debug.ShouldStop(536870912);
_writer.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_nomefile,anywheresoftware.b4a.keywords.Common.True).getObject()));
 BA.debugLineNum = 127;BA.debugLine="Writer.Write(Write)";
Debug.ShouldStop(1073741824);
_writer.Write(_write);
 BA.debugLineNum = 128;BA.debugLine="Writer.Close";
Debug.ShouldStop(-2147483648);
_writer.Close();
 BA.debugLineNum = 129;BA.debugLine="End Sub";
Debug.ShouldStop(1);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _writefileriga(String _nomefile,String _buffer,long _riga) throws Exception{
		Debug.PushSubsStack("WriteFileRiga (psy) ","psy",1,processBA,mostCurrent);
try {
String[] _iline = null;
String _nuovobuffer = "";
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _writer = null;
int _start = 0;
Debug.locals.put("NomeFile", _nomefile);
Debug.locals.put("Buffer", _buffer);
Debug.locals.put("Riga", _riga);
 BA.debugLineNum = 145;BA.debugLine="Sub WriteFileRiga(NomeFile As String,Buffer As String,Riga As Long)";
Debug.ShouldStop(65536);
 BA.debugLineNum = 146;BA.debugLine="Dim iLine() As String";
Debug.ShouldStop(131072);
_iline = new String[(int)(0)];
java.util.Arrays.fill(_iline,"");Debug.locals.put("iLine", _iline);
 BA.debugLineNum = 147;BA.debugLine="Dim NuovoBuffer As String";
Debug.ShouldStop(262144);
_nuovobuffer = "";Debug.locals.put("NuovoBuffer", _nuovobuffer);
 BA.debugLineNum = 148;BA.debugLine="Dim Writer As TextWriter";
Debug.ShouldStop(524288);
_writer = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("Writer", _writer);
 BA.debugLineNum = 149;BA.debugLine="Riga = Riga-1";
Debug.ShouldStop(1048576);
_riga = (long)(_riga-1);Debug.locals.put("Riga", _riga);
 BA.debugLineNum = 150;BA.debugLine="iLine = Regex.Split(Chr(13),ReadFile(NomeFile))";
Debug.ShouldStop(2097152);
_iline = anywheresoftware.b4a.keywords.Common.Regex.Split(String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(13))),_readfile(_nomefile));Debug.locals.put("iLine", _iline);
 BA.debugLineNum = 151;BA.debugLine="If iLine.Length -1 < Riga  Then";
Debug.ShouldStop(4194304);
if (_iline.length-1<_riga) { 
 BA.debugLineNum = 152;BA.debugLine="WriteFile(NomeFile,Buffer)";
Debug.ShouldStop(8388608);
_writefile(_nomefile,_buffer);
 BA.debugLineNum = 153;BA.debugLine="Return \"\"";
Debug.ShouldStop(16777216);
if (true) return "";
 }else {
 BA.debugLineNum = 155;BA.debugLine="For start = 0 To iLine.Length -1";
Debug.ShouldStop(67108864);
{
final double step97 = 1;
final double limit97 = (int)(_iline.length-1);
for (_start = (int)(0); (step97 > 0 && _start <= limit97) || (step97 < 0 && _start >= limit97); _start += step97) {
Debug.locals.put("start", _start);
 BA.debugLineNum = 156;BA.debugLine="If start = 0 Then";
Debug.ShouldStop(134217728);
if (_start==0) { 
 BA.debugLineNum = 157;BA.debugLine="NuovoBuffer = iLine(start) & Chr(10)";
Debug.ShouldStop(268435456);
_nuovobuffer = _iline[_start]+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(10)));Debug.locals.put("NuovoBuffer", _nuovobuffer);
 }else {
 BA.debugLineNum = 159;BA.debugLine="If start = Riga Then";
Debug.ShouldStop(1073741824);
if (_start==_riga) { 
 BA.debugLineNum = 160;BA.debugLine="NuovoBuffer = NuovoBuffer & Buffer & Chr(10)";
Debug.ShouldStop(-2147483648);
_nuovobuffer = _nuovobuffer+_buffer+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(10)));Debug.locals.put("NuovoBuffer", _nuovobuffer);
 }else {
 BA.debugLineNum = 162;BA.debugLine="NuovoBuffer = NuovoBuffer & iLine(start) & Chr(10)";
Debug.ShouldStop(2);
_nuovobuffer = _nuovobuffer+_iline[_start]+String.valueOf(anywheresoftware.b4a.keywords.Common.Chr((int)(10)));Debug.locals.put("NuovoBuffer", _nuovobuffer);
 };
 };
 }
}Debug.locals.put("start", _start);
;
 };
 BA.debugLineNum = 169;BA.debugLine="Writer.Initialize(File.OpenOutput(File.DirInternal, NomeFile, False))";
Debug.ShouldStop(256);
_writer.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),_nomefile,anywheresoftware.b4a.keywords.Common.False).getObject()));
 BA.debugLineNum = 170;BA.debugLine="Writer.Write(NuovoBuffer)";
Debug.ShouldStop(512);
_writer.Write(_nuovobuffer);
 BA.debugLineNum = 171;BA.debugLine="Writer.Close";
Debug.ShouldStop(1024);
_writer.Close();
 BA.debugLineNum = 173;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _writesocket(String _read) throws Exception{
		Debug.PushSubsStack("WriteSocket (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
Debug.locals.put("Read", _read);
 BA.debugLineNum = 419;BA.debugLine="Sub WriteSocket(Read As String)";
Debug.ShouldStop(4);
 BA.debugLineNum = 420;BA.debugLine="Try";
Debug.ShouldStop(8);
try { BA.debugLineNum = 421;BA.debugLine="If socket_ricezione_dati.Connected == True AND joinpasswd == True AND Read.Length > 0 Then";
Debug.ShouldStop(16);
if (_socket_ricezione_dati.getConnected()==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True && _read.length()>0) { 
 BA.debugLineNum = 423;BA.debugLine="Dim tr As TextReader";
Debug.ShouldStop(64);
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();Debug.locals.put("tr", _tr);
 BA.debugLineNum = 424;BA.debugLine="Dim tw As TextWriter";
Debug.ShouldStop(128);
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("tw", _tw);
 BA.debugLineNum = 425;BA.debugLine="tr.Initialize( socket_ricezione_dati.InputStream)";
Debug.ShouldStop(256);
_tr.Initialize(_socket_ricezione_dati.getInputStream());
 BA.debugLineNum = 426;BA.debugLine="tw.Initialize( socket_ricezione_dati.OutputStream)";
Debug.ShouldStop(512);
_tw.Initialize(_socket_ricezione_dati.getOutputStream());
 BA.debugLineNum = 427;BA.debugLine="tw.WriteLine(Read)";
Debug.ShouldStop(1024);
_tw.WriteLine(_read);
 BA.debugLineNum = 428;BA.debugLine="tw.Flush";
Debug.ShouldStop(2048);
_tw.Flush();
 BA.debugLineNum = 429;BA.debugLine="Return Read";
Debug.ShouldStop(4096);
if (true) return _read;
 };
 } 
       catch (Exception e310) {
			processBA.setLastException(e310); BA.debugLineNum = 432;BA.debugLine="socket_ricezione_dati.Close";
Debug.ShouldStop(32768);
_socket_ricezione_dati.Close();
 };
 BA.debugLineNum = 434;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static String  _writesocketirc(String _read) throws Exception{
		Debug.PushSubsStack("WriteSocketIrc (psy) ","psy",1,processBA,mostCurrent);
try {
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
String _realdata = "";
int _i = 0;
Debug.locals.put("Read", _read);
 BA.debugLineNum = 435;BA.debugLine="Sub WriteSocketIrc(Read As String)";
Debug.ShouldStop(262144);
 BA.debugLineNum = 436;BA.debugLine="Try";
Debug.ShouldStop(524288);
try { BA.debugLineNum = 437;BA.debugLine="If socket_invio_dati.Connected = True Then";
Debug.ShouldStop(1048576);
if (_socket_invio_dati.getConnected()==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 438;BA.debugLine="Dim tr As TextReader";
Debug.ShouldStop(2097152);
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();Debug.locals.put("tr", _tr);
 BA.debugLineNum = 439;BA.debugLine="Dim tw As TextWriter";
Debug.ShouldStop(4194304);
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();Debug.locals.put("tw", _tw);
 BA.debugLineNum = 440;BA.debugLine="tr.Initialize(socket_invio_dati.InputStream)";
Debug.ShouldStop(8388608);
_tr.Initialize(_socket_invio_dati.getInputStream());
 BA.debugLineNum = 441;BA.debugLine="tw.Initialize(socket_invio_dati.OutputStream)";
Debug.ShouldStop(16777216);
_tw.Initialize(_socket_invio_dati.getOutputStream());
 BA.debugLineNum = 442;BA.debugLine="tw.WriteLine(Read)";
Debug.ShouldStop(33554432);
_tw.WriteLine(_read);
 BA.debugLineNum = 443;BA.debugLine="tw.Flush";
Debug.ShouldStop(67108864);
_tw.Flush();
 BA.debugLineNum = 444;BA.debugLine="Return Read";
Debug.ShouldStop(134217728);
if (true) return _read;
 };
 } 
       catch (Exception e325) {
			processBA.setLastException(e325); BA.debugLineNum = 447;BA.debugLine="If IRClient == True AND joinpasswd = True Then";
Debug.ShouldStop(1073741824);
if (_irclient==anywheresoftware.b4a.keywords.Common.True && _joinpasswd==anywheresoftware.b4a.keywords.Common.True) { 
 BA.debugLineNum = 449;BA.debugLine="Dim RealData As String";
Debug.ShouldStop(1);
_realdata = "";Debug.locals.put("RealData", _realdata);
 BA.debugLineNum = 450;BA.debugLine="RealData = GeneraDAtaUnix";
Debug.ShouldStop(2);
_realdata = _generadataunix();Debug.locals.put("RealData", _realdata);
 BA.debugLineNum = 451;BA.debugLine="For I = 0 To joinchannel.Size - 1";
Debug.ShouldStop(4);
{
final double step328 = 1;
final double limit328 = (int)(_joinchannel.getSize()-1);
for (_i = (int)(0); (step328 > 0 && _i <= limit328) || (step328 < 0 && _i >= limit328); _i += step328) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 452;BA.debugLine="WriteSocket(\":\"&Nickconnessione&\" PART \"&joinchannel.Get(I))";
Debug.ShouldStop(8);
_writesocket(":"+_nickconnessione+" PART "+String.valueOf(_joinchannel.Get(_i)));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 454;BA.debugLine="WriteSocket(\":-psyBNC PRIVMSG psyBNC \"&RealData&\" User \"&Solouser(identIRC)&\" got disconnected from server.\")";
Debug.ShouldStop(32);
_writesocket(":-psyBNC PRIVMSG psyBNC "+_realdata+" User "+_solouser(_identirc)+" got disconnected from server.");
 };
 BA.debugLineNum = 456;BA.debugLine="socket_invio_dati.close";
Debug.ShouldStop(128);
_socket_invio_dati.Close();
 };
 BA.debugLineNum = 460;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return "";
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
  public Object[] GetGlobals() {
		return new Object[] {"Service",_service,"server",_server,"serverPort",_serverport,"statesocket",_statesocket,"socket_ricezione_dati",_socket_ricezione_dati,"socket_invio_dati",_socket_invio_dati,"datisocket_ricezione",_datisocket_ricezione,"datisocket_ricezione_irc",_datisocket_ricezione_irc,"IRClient",_irclient,"MyIP",_myip,"Timerserver",_timerserver,"joinpasswd",_joinpasswd,"joinchannel",_joinchannel,"Topichannel",_topichannel,"MessageQuery",_messagequery,"identIRC",_identirc,"Nickconnessione",_nickconnessione,"SaveMoth",_savemoth,"StopMoth",_stopmoth,"AwayNick",_awaynick,"NormalNick",_normalnick,"PingTimer",_pingtimer,"AutoPing",_autoping,"Main",Debug.moduleToString(psybnc.pack.main.class)};
}
}
